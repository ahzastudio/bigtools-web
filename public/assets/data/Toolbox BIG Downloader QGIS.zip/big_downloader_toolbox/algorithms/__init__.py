# -*- coding: utf-8 -*-
"""
Algorithms for BIG Downloader Toolbox
"""