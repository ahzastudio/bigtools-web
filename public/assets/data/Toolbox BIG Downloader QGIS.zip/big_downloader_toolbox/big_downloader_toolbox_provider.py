# -*- coding: utf-8 -*-
"""
BIG Downloader Toolbox Provider - SIMPLIFIED VERSION
"""

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
import os


class BIGDownloaderToolboxProvider(QgsProcessingProvider):
    """Provider untuk BIG Downloader Toolbox"""

    def __init__(self):
        super().__init__()

    def loadAlgorithms(self):
        """Load all algorithms - DEFENSIVE VERSION"""
        algorithms_loaded = 0

        # Load Login
        try:
            from .algorithms.login_demnas import LoginDEMNAS
            self.addAlgorithm(LoginDEMNAS())
            algorithms_loaded += 1
        except Exception as e:
            print(f"⚠️ Error loading LoginDEMNAS: {str(e)}")

        # Load DEMNAS
        try:
            from .algorithms.download_demnas_pro import DownloadDemnasPro
            self.addAlgorithm(DownloadDemnasPro())
            algorithms_loaded += 1
        except Exception as e:
            print(f"⚠️ Error loading DownloadDemnasPro: {str(e)}")

        # Load RBI
        try:
            from .algorithms.download_rbi_tool_pro import DownloadRBIToolPro
            self.addAlgorithm(DownloadRBIToolPro())
            algorithms_loaded += 1
        except Exception as e:
            print(f"⚠️ Error loading DownloadRBIToolPro: {str(e)}")

        # Load BATNAS
        try:
            from .algorithms.download_batnas import DownloadBATNAS
            self.addAlgorithm(DownloadBATNAS())
            algorithms_loaded += 1
        except Exception as e:
            print(f"⚠️ Error loading DownloadBATNAS: {str(e)}")

        # Load Batas Wilayah
        try:
            from .algorithms.download_batas_wilayah import DownloadBatasWilayah
            self.addAlgorithm(DownloadBatasWilayah())
            algorithms_loaded += 1
        except Exception as e:
            print(f"⚠️ Error loading DownloadBatasWilayah: {str(e)}")

        print(
            f"✅ BIG Downloader: {algorithms_loaded}/5 algorithms loaded "
            "successfully"
        )

    def id(self):
        """Unique provider ID"""
        return 'big_downloader'

    def name(self):
        """Provider name"""
        return 'BIG Downloader'

    def icon(self):
        """Provider icon"""
        # Coba icon utama dulu
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        if os.path.exists(icon_path):
            return QIcon(icon_path)

        # Fallback ke default icon
        return super().icon()

    def longName(self):
        """Long provider name"""
        return 'BIG Downloader - Download DEMNAS, RBI, BATNAS'