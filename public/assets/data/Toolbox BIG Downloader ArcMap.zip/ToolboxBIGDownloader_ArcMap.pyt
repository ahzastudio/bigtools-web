# -*- #################
"""
Toolbox untuk mengunduh tile DEMNAS (Digital Elevation Model Nasional) Indonesia
Versi ArcGIS Desktop (ArcMap) / Python 2.7
"""

import arcpy
import os
import urllib2
import urllib
import ssl
import time
import re
import random
import webbrowser
import json
from datetime import datetime
import uuid
import platform
import getpass
from arcpy.sa import *
import sys
import traceback
import base64
import base64
import tempfile
import shutil

# ============================================================================================
# TOOLBOX UTAMA
# ============================================================================================


# ===================================================================================
#  SUPABASE LICENSE GUARD (PYTHON 2.7 COMPATIBLE)
# ===================================================================================
class SupabaseGuard:
    SUPABASE_URL = "https://mbfzmvlivyuajmxrecne.supabase.co"
    SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1iZnptdmxpdnl1YWpteHJlY25lIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU0NzgwODQsImV4cCI6MjA4MTA1NDA4NH0.sZltNY30ww2Hb_oopiVDcvXnZRehWRvK2jZZU5MO64s"
    TABLE_NAME = "licenses"
    
    # KONTAK ADMIN
    ADMIN_NAME = "Ardi Abu Ridho"
    ADMIN_WA   = "+62 822-5476-0769"
    VERSION    = "4.0.0"
    
    @staticmethod
    def get_machine_id():
        try:
            # Try to get UUID via WMIC (Most stable)
            import subprocess
            cmd = 'wmic csproduct get uuid'
            # Use startupinfo to hide console window in ArcMap
            si = None
            if os.name == 'nt':
                si = subprocess.STARTUPINFO()
                si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            
            output = subprocess.check_output(cmd, shell=True, startupinfo=si).decode().strip()
            lines = output.split(os.linesep)
            if len(lines) > 1:
                val = lines[1].strip()
                if val and val != 'FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF':
                    return val.replace('-', '')[:12].lower()
            
            # Fallback to MAC Address if WMIC fails
            node = uuid.getnode()
            return hex(node)[2:].rstrip('L').lower()
        except:
            try:
                node = uuid.getnode()
                return hex(node)[2:].rstrip('L').lower()
            except:
                return "UNKNOWN_DEVICE"

    @staticmethod
    def make_request(url, method="GET", data=None):
        headers = {
            "apikey": SupabaseGuard.SUPABASE_KEY,
            "Authorization": "Bearer {0}".format(SupabaseGuard.SUPABASE_KEY),
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }
        
        req_data = json.dumps(data) if data else None
        
        # Python 2.7 urllib2 request
        try:
            req = urllib2.Request(url, data=req_data, headers=headers)
            req.get_method = lambda: method # Override method for PATCH/PUT
            
            # Create unverified context properly for Python 2.7.9+
            if hasattr(ssl, '_create_unverified_context'):
                context = ssl._create_unverified_context()
                response = urllib2.urlopen(req, context=context)
            else:
                response = urllib2.urlopen(req)
                
            resp_body = response.read()
            return json.loads(resp_body) if resp_body else []
                
        except urllib2.HTTPError as e:
            # print("HTTP Error: {}".format(e.code))
            return None
        except Exception as e:
            # print("Request Error: {}".format(str(e)))
            return None

    @staticmethod
    def format_status_box(status, expiry, days_left, app_name, tier, machine_id=None):
        border = "=" * 60
        nl = chr(10)
        
        expiry_text = "Seumur Hidup"
        if expiry:
            expiry_text = "{0} (Sisa {1} hari)".format(expiry, days_left)
            
        lines = []
        lines.append(nl + border)
        lines.append(" STATUS LISENSI (AHZA TOOLS)")
        lines.append(border)
        lines.append(" Aplikasi     : {0}".format(app_name))
        lines.append(" Versi        : {0}".format(SupabaseGuard.VERSION))
        lines.append(" Status       : {0}".format(status.upper()))
        lines.append(" Tipe Paket   : {0}".format(tier.upper()))
        lines.append(" Masa Aktif   : {0}".format(expiry_text))
        
        if machine_id:
            lines.append(" Machine ID   : {0}".format(machine_id))
            
        lines.append("")
        lines.append(" Hubungi Admin jika ada kendala:")
        lines.append(" {0} ({1})".format(SupabaseGuard.ADMIN_NAME, SupabaseGuard.ADMIN_WA))
        lines.append(border + nl)
        
        return nl.join(lines)

    @staticmethod
    def check_license(app_name="BIG Downloader ArcMap", minimum_tier="free", show_machine_id=True):
        try:
            safe_app = "".join(c if c.isalnum() else "_" for c in app_name).lower()
            minimum_tier = minimum_tier.lower()
            
            tier_levels = {"free": 1, "basic": 2, "pro": 3}
            
            machine_id = SupabaseGuard.get_machine_id()
            mid_display = machine_id if show_machine_id else None
            base_url = SupabaseGuard.SUPABASE_URL
            table = SupabaseGuard.TABLE_NAME
            
            # Query Existing
            query = urllib.urlencode({
                "machine_id": "eq.{0}".format(machine_id),
                "app_name": "eq.{0}".format(safe_app),
                "select": "*"
            })
            url = "{0}/rest/v1/{1}?{2}".format(base_url, table, query)
            
            data = SupabaseGuard.make_request(url, "GET")
            if data is None: 
                return False, "[ERROR] Gagal koneksi internet ke server lisensi.", {}
            
            final_data = None
            
            if not data:
                # REGISTER NEW (Default Tier: basic)
                try:
                    hostname = platform.node()
                    username = getpass.getuser()
                    auto_client = "{0} ({1}) [ArcMap]".format(hostname, username)
                except:
                    auto_client = "Unknown PC [ArcMap]"

                # utcnow for py2 compatibility
                now_iso = datetime.utcnow().isoformat()
                
                payload = {
                    "machine_id": machine_id,
                    "app_name": safe_app,
                    "last_check": now_iso,
                    "tier": "free",       # FORCE FREE (LIFETIME)
                    "status": "active",   # FORCE ACTIVE
                    "expiry_date": None,  # FORCE NO EXPIRY
                    "client_name": auto_client,
                    "version": SupabaseGuard.VERSION
                }
                post_url = "{0}/rest/v1/{1}".format(base_url, table)
                new_data = SupabaseGuard.make_request(post_url, "POST", payload)
                if not new_data: return False, "Gagal Registrasi Trial.", {}
                final_data = new_data[0]
            else:
                final_data = data[0]

                # --- AUTO-UPDATE LOGIC: TRIAL -> ACTIVE FREE LIFETIME ---
                current_status = final_data.get("status", "").lower()
                if current_status in ["trial", "banned", "expired"]: 
                    try:
                        patch_params = {
                            "machine_id": "eq.{0}".format(machine_id), 
                            "app_name": "eq.{0}".format(safe_app)
                        }
                        patch_query = urllib.urlencode(patch_params)
                        patch_url = "{0}/rest/v1/{1}?{2}".format(base_url, table, patch_query)
                        
                        patch_data = {
                            "status": "active",
                            "tier": "free",
                            "expiry_date": None,
                            "tier": "free",
                            "expiry_date": None,
                            "last_check": datetime.utcnow().isoformat(),
                            "version": SupabaseGuard.VERSION
                        }
                        SupabaseGuard.make_request(patch_url, "PATCH", patch_data)
                        
                        final_data["status"] = "active"
                        final_data["tier"] = "free"
                        final_data["expiry_date"] = None
                    except:
                        pass
                else:
                    # Normal heartbeat
                    q_upd = urllib.urlencode({"machine_id": "eq.{0}".format(machine_id), "app_name": "eq.{0}".format(safe_app)})
                    url_upd = "{0}/rest/v1/{1}?{2}".format(base_url, table, q_upd)
                    
                    # Auto-detect client info for analytics
                    try:
                        hostname = platform.node()
                        username = getpass.getuser()
                        auto_client = "{0} ({1}) [ArcMap]".format(hostname, username)
                    except:
                        auto_client = "Unknown PC [ArcMap]"

                    SupabaseGuard.make_request(url_upd, "PATCH", {
                        "last_check": datetime.utcnow().isoformat(),
                        "version": SupabaseGuard.VERSION,
                        "client_name": auto_client
                    })

            # =========================================================================
            # GLOBAL CLEANUP
            # =========================================================================
            _tier = final_data.get("tier", "").lower()
            _status = final_data.get("status", "").lower()
            _expiry = final_data.get("expiry_date")
            
            should_cleanup = False
            if _tier == "free" and _expiry is not None: should_cleanup = True
            if _status == "trial": should_cleanup = True
            if _tier == "pro": should_cleanup = True
            
            if should_cleanup:
                try:
                    patch_params = {
                        "machine_id": "eq.{0}".format(machine_id), 
                        "app_name": "eq.{0}".format(safe_app)
                    }
                    patch_query = urllib.urlencode(patch_params)
                    patch_url = "{0}/rest/v1/{1}?{2}".format(base_url, table, patch_query)
                    
                    patch_data = {
                        "status": "active",
                        "tier": "free",
                        "expiry_date": None,
                        "last_check": datetime.utcnow().isoformat()
                    }
                    
                    SupabaseGuard.make_request(patch_url, "PATCH", patch_data)
                    
                    final_data["status"] = "active"
                    final_data["tier"] = "free"
                    final_data["expiry_date"] = None
                    
                except Exception:
                    pass
            # =========================================================================

            status = final_data.get("status", "trial").lower()
            tier = final_data.get("tier", "basic").lower()
            expiry = final_data.get("expiry_date")
            days_left = 0
            
            info = {
                "tier": tier,
                "status": status,
                "expiry": expiry
            }

            if status == "banned": 
                return False, SupabaseGuard.format_status_box("BANNED", expiry, 0, safe_app, tier, mid_display), info
            
            user_level = 1 
            
            if status == "trial":
                if expiry:
                    try:
                        exp_date = datetime.strptime(expiry, "%Y-%m-%d")
                        now_date = datetime.now()
                        days_left = (exp_date - now_date).days
                        info["days_left"] = days_left
                        
                        if days_left > 0:
                            user_level = 3 
                        else:
                            user_level = 1 
                            status = "TRIAL EXPIRED (FREE MODE)" 
                    except: 
                        user_level = 1
                else:
                    user_level = 3
            elif status == "active":
                user_level = tier_levels.get(tier, 1)
            elif status == "expired":
                user_level = 1
                status = "SUBSCRIPTION EXPIRED (FREE MODE)"
            
            req_lev = tier_levels.get(minimum_tier, 1)
            
            if user_level < req_lev:
                  req_tier_name = minimum_tier.upper()
                  user_tier_name = "FREE"
                  if user_level == 2: user_tier_name = "BASIC"
                  elif user_level == 3: user_tier_name = "PRO"
                  
                  msg_tier = SupabaseGuard.format_status_box(status, expiry, days_left, safe_app, user_tier_name, mid_display)
                  
                  detail_msg = "\n[ACCESS DENIED] Fitur ini eksklusif untuk paket {0}.".format(req_tier_name)
                  detail_msg += "\nPaket Anda saat ini: {0}.".format(user_tier_name)
                  
                  return False, msg_tier + detail_msg, info
            
            msg = SupabaseGuard.format_status_box(status, expiry, days_left, safe_app, tier, mid_display)
            return True, msg, info

        except Exception as e:
            return False, "License Logic Error: {0}".format(str(e)), {}

class Toolbox(object):
    def __init__(self):
        """Mendefinisikan toolbox DEMNAS Downloader untuk ArcGIS Desktop (ArcMap)."""
        self.label = "BIG Downloader Tools (v4.0.0)"
        self.alias = "BIGDownloaderTools_v2"
        self.tools = [LoginDEMNAS,DownloadDemnasArcMap,DownloadRBIToolArcMap,DownloadBATNASArcMap,DownloadBatasWilayahArcMap]

# ============================================================================================
# 1. LOGIN DEMNAS
# ============================================================================================

class LoginDEMNAS(object):
    def __init__(self):
        self.label = "1. Login INA-Geoportal"
        self.description = "Buka halaman login DEMNAS dan ikuti panduan untuk mengambil token."

    def getParameterInfo(self):
        panduan = arcpy.Parameter(
            displayName="Panduan Mengambil Token DEMNAS",
            name="panduan_token",
            datatype="GPString",
            parameterType="Optional",
            direction="Input",
            multiValue=True
        )
        panduan.value = [
            "=== PANDUAN MENGAMBIL TOKEN DEMNAS ===",
            " ",
            "1. Klik tombol [Run] di bawah untuk membuka halaman login.",
            "2. Tekan [F12] untuk membuka Developer Tools.",
            "3. Masuk ke tab [Network].",
            "4. Login dengan akun DEMNAS Anda.",
            "5. Kembali ke tab [Network], lalu pada Header/Field Name cari {;}signin, dan klik.",
            "6. Pada bagian kanan akan muncul Header,Payload, Preview dan Response.",
            "7. Ambil nilai 'accessToken:'  dari bagian Preview atau Response.",
            "8. Pastikan Anda sudah logout saat menjalankan tools ini.",
            " ",
            "Gunakan token tersebut di Tool #2 (Unduh DEMNAS)."
        ]
        return [panduan]

    def isLicensed(self):
        return True

    def updateParameters(self, parameters):
        return

    def updateMessages(self, parameters):
        return

    def execute(self, parameters, messages):
        # --- LICENSE CHECK START (LOGIN) ---
        valid, msg, info = SupabaseGuard.check_license(app_name="BIG Downloader", minimum_tier="free", show_machine_id=False)
        messages.addMessage(msg)
        if not valid:
             raise Exception("Lisensi tidak valid. Hubungi admin.")
        # --- LICENSE CHECK END ---

        url = "https://tanahair.indonesia.go.id/portal-web/login"
        webbrowser.open(url)
        messages.addMessage("Browser telah dibuka. Silakan ikuti panduan di kolom parameter.")

# ============================================================================================
# 2. DOWNLOAD DEMNAS (ARCMAP VERSION)
# ============================================================================================

class DownloadDemnasArcMap(object):
    def __init__(self):
        self.label = "2. Download DEMNAS (Mosaic)"
        self.description = "Download tile DEMNAS with improved clipping and output format"
        self.canRunInBackground = False

    def getParameterInfo(self):
        params = [
            # Parameter 0: DEMNAS index grid layer
            arcpy.Parameter(
                displayName="DEMNAS Index Grid",
                name="index_dem",
                datatype="GPFeatureLayer",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 1: Area of Interest (AOI)
            arcpy.Parameter(
                displayName="Area of Interest (AOI)",
                name="aoi",
                datatype="GPFeatureLayer",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 2: API Token
            arcpy.Parameter(
                displayName="API Token",
                name="token",
                datatype="GPString",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 3: Output Location
            arcpy.Parameter(
                displayName="Output Location (Folder or Geodatabase)",
                name="output_location",
                datatype="DEWorkspace",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 4: Output Name
            arcpy.Parameter(
                displayName="Output Name (without extension)",
                name="output_name",
                datatype="GPString",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 5: Clip with AOI
            arcpy.Parameter(
                displayName="Clip DEM with AOI?",
                name="clip_dem",
                datatype="GPBoolean",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 6: Output Coordinate System
            arcpy.Parameter(
                displayName="Output Coordinate System",
                name="output_crs",
                datatype="GPSpatialReference",
                parameterType="Optional",
                direction="Input"),
            
            # Parameter 7: Buffer Distance
            arcpy.Parameter(
                displayName="Buffer Distance (meters)",
                name="buffer_distance",
                datatype="GPDouble",
                parameterType="Optional",
                direction="Input")
        ]
        
        params[4].value = "DEMNAS_Output"
        params[5].value = True
        params[7].value = 100.0
        
        return params

    def isLicensed(self):
        return True

    def updateParameters(self, parameters):
        # Dynamic Enable/Disable Buffer
        if parameters[5].value is True:  # Clip Checked
            parameters[7].enabled = True
        else:
            parameters[7].enabled = False
            
        if parameters[3].value is None and not parameters[3].altered:
            try:
                # ArcMap default gdb
                if hasattr(arcpy.env, 'scratchGDB'):
                    parameters[3].value = arcpy.env.scratchGDB
            except:
                pass
        return

    def updateMessages(self, parameters):
        return
        
    def execute(self, parameters, messages):
        start_time = time.time()

        index_dem = parameters[0].valueAsText
        aoi = parameters[1].valueAsText
        token = parameters[2].valueAsText
        output_location = parameters[3].valueAsText
        output_name = parameters[4].valueAsText
        clip_dem = parameters[5].value
        output_crs = parameters[6].value
        buffer_dist = parameters[7].value
        
        # --- LICENSE CHECK START (DEMNAS) ---
        valid, msg, info = SupabaseGuard.check_license(app_name="BIG Downloader", minimum_tier="free")
        messages.addMessage(msg)
        if not valid:
             raise Exception("Lisensi tidak valid. Hubungi admin.")
        # --- LICENSE CHECK END ---

        mosaic_path = None
        temp_files = []
        final_outputs = []
        
        try:
            if not token or len(token.strip()) < 10:
                raise ValueError("Token API valid atau kosong!")

            if not arcpy.Exists(output_location):
                raise ValueError("Lokasi output tidak ditemukan: {0}".format(output_location))

            arcpy.env.overwriteOutput = True
            arcpy.env.compression = "LZW"
            
            # 1. Select tiles
            count, tile_names = self.select_tiles(index_dem, aoi, messages)
            if count == 0:
                return

            # 2. Download tiles
            messages.addMessage("\n=== MENGUNDUH TILE ===")
            tile_paths = []
            for dem_name in tile_names:
                try:
                    temp_dir = tempfile.mkdtemp()
                    temp_tif = os.path.join(temp_dir, "{0}.tif".format(dem_name))
                    self.download_tile(dem_name, token, temp_tif, messages)
                    
                    if arcpy.Exists(temp_tif):
                        self.define_projection(temp_tif, 4326, messages)
                        corrected_tif = os.path.join(temp_dir, "{0}_corrected.tif".format(dem_name))
                        
                        # Raster algebra in Py2.7
                        ras = arcpy.Raster(temp_tif)
                        out_con = Con(ras < 0, 0, ras)
                        out_con.save(corrected_tif)
                        
                        tile_paths.append(corrected_tif)
                        # temp_files.extend([temp_tif, corrected_tif])
                        messages.addMessage("Berhasil: {0}".format(dem_name))

                    # Track directory for cleanup
                    temp_files.append(temp_dir)
                except Exception as e:
                    messages.addWarningMessage("Gagal memproses {0}: {1}".format(dem_name, str(e)))

            if not tile_paths:
                raise Exception("Tidak ada tile yang berhasil diproses")

            # 3. Create Mosaic
            messages.addMessage("\n=== MEMBUAT MOSAIK ===")
            mosaic_dir = tempfile.mkdtemp()
            temp_files.append(mosaic_dir)
            
            mosaic_path = os.path.join(mosaic_dir, "DEMNAS_Mosaic.tif")
            desc = arcpy.Describe(tile_paths[0])
            cell_size = desc.meanCellWidth
            
            # Joining path list for MosaicToNewRaster (semicolon separated)
            # input_rasters in Py2.7 sometimes needs string
            input_rasters_str = ";".join(tile_paths)
            
            arcpy.MosaicToNewRaster_management(
                input_rasters=input_rasters_str,
                output_location=mosaic_dir,
                raster_dataset_name_with_extension="DEMNAS_Mosaic.tif",
                coordinate_system_for_the_raster=arcpy.SpatialReference(4326),
                pixel_type="32_BIT_FLOAT",
                cellsize=cell_size,
                number_of_bands=1,
                mosaic_method="BLEND",
                mosaic_colormap_mode="FIRST"
            )
            temp_files.append(mosaic_path)

            # 4. Final output
            is_gdb = output_location.lower().endswith('.gdb')
            
            # Determine suffix
            suffix = ""
            if clip_dem:
                suffix += "_clip"
            
            if output_crs and output_crs.factoryCode != 4326:
                suffix += "_utm"
                
            output_path = os.path.join(output_location, "{0}{1}".format(output_name, suffix).replace(" ", "_"))
            if not is_gdb:
                output_path += ".tif"

            current_raster = mosaic_path

            if clip_dem:
                messages.addMessage("\n=== MEMOTONG SESUAI AOI (BUFFER: {0}m) ===".format(buffer_dist))
                temp_clipped = os.path.join(mosaic_dir, "temp_clipped.tif")
                self.clip_raster(current_raster, aoi, temp_clipped, messages, buffer_dist)
                current_raster = temp_clipped
            
            # 5. Optional projection / Copy
            if output_crs and output_crs.factoryCode != 4326:
                 messages.addMessage("\n=== PROYEKSI OUTPUT ({0}) ===".format(output_crs.name))
                 arcpy.ProjectRaster_management(
                     current_raster,
                     output_path,
                     output_crs,
                     resampling_type="BILINEAR"
                 )
            else:
                 # Copy if not projected (just move/save final)
                     arcpy.CopyRaster_management(current_raster, output_path)

            final_outputs.append(output_path)
            
            # 6. Add to map
            for output in final_outputs:
                output_n = os.path.basename(output).split('.')[0]
                self.add_to_map(output, output_n, messages)
            
            # 7. Print summary
            self.print_summary(count, len(tile_paths), start_time, messages)

        except Exception as e:
            arcpy.AddError("ERROR: {0}".format(str(e)))
            raise
        finally:
            # Clean up temp
            try:
                for tf in temp_files:
                    if os.path.isdir(tf):
                        shutil.rmtree(tf, ignore_errors=True)
                    elif os.path.exists(tf):
                        try: os.remove(tf)
                        except: pass
            except: pass

    def clip_raster(self, input_raster, aoi, output_path, messages, buffer_dist=100.0):
        try:
            temp_dir = tempfile.mkdtemp()
            temp_aoi = os.path.join(temp_dir, "aoi_feature.shp")
            temp_buffered_aoi = os.path.join(temp_dir, "aoi_buffered.shp")
            temp_output = os.path.join(temp_dir, "output_clip.tif")
            
            # Export AOI to shapefile
            desc_aoi = arcpy.Describe(aoi)
            if desc_aoi.catalogPath.endswith('.shp'):
                temp_aoi = desc_aoi.catalogPath
            else:
                arcpy.FeatureClassToFeatureClass_conversion(aoi, temp_dir, "aoi_feature.shp")
            
            # Apply buffer if buffer_dist > 0
            clip_feature = temp_aoi
            if buffer_dist and buffer_dist > 0:
                messages.addMessage("Membuffer AOI sebesar {0} meter...".format(buffer_dist))
                arcpy.Buffer_analysis(
                    in_features=temp_aoi,
                    out_feature_class=temp_buffered_aoi,
                    buffer_distance_or_field="{0} Meters".format(buffer_dist),
                    dissolve_option="ALL"
                )
                clip_feature = temp_buffered_aoi
            
            # Try multiple clipping methods with fallbacks
            try:
                # Method 1: ExtractByMask with Spatial Analyst (Prioritas Utama - Lebih Rapi)
                if arcpy.CheckExtension("Spatial") == "Available":
                    arcpy.CheckOutExtension("Spatial")
                    # Use original input directly with buffered AOI
                    out_raster = ExtractByMask(input_raster, clip_feature)
                    out_raster.save(temp_output)  # SAVE to temp file
                    arcpy.CheckInExtension("Spatial")
                    # Release raster object explicitly to prevent locks
                    del out_raster
                    messages.addMessage("Berhasil memotong menggunakan ExtractByMask")
                else:
                    raise Exception("Spatial Analyst tidak tersedia")
                    
            except Exception as e1:
                # Method 2: Clip Management (Fallback)
                # messages.addWarningMessage("ExtractByMask gagal. Mencoba Clip Management...")
                try:
                    # Release previous exception objects if any
                    sys.exc_clear()
                    
                    # Pastikan extent envelope mencakup polygon
                    extent = arcpy.Describe(clip_feature).extent
                    
                    arcpy.Clip_management(
                        in_raster=input_raster, 
                        rectangle="{0} {1} {2} {3}".format(extent.XMin, extent.YMin, extent.XMax, extent.YMax),
                        out_raster=temp_output,
                        in_template_dataset=clip_feature,
                        nodata_value="#",
                        clipping_geometry="ClippingGeometry", 
                        maintain_clipping_extent="MAINTAIN_EXTENT"
                    )
                    messages.addMessage("Berhasil memotong menggunakan Clip Management")
                    
                except Exception as e2:
                     raise Exception("Semua metode pemotongan gagal. Error 1: {0}. Error 2: {1}".format(str(e1), str(e2)))
            
            # Safe Overwrite
            if arcpy.Exists(output_path):
                try:
                    arcpy.Delete_management(output_path)
                except:
                    messages.addWarningMessage("File output sudah ada dan terkunci (mungkin sedang dibuka di peta). Mencoba menimpa...")
            
            arcpy.CopyRaster_management(temp_output, output_path)
            # messages.addMessage("Output final disimpan di: {0}".format(output_path)) # Removed
            
            # clean temp
            try:
                # Force release locks
                if 'temp_output' in locals() and arcpy.Exists(temp_output):
                    arcpy.Delete_management(temp_output)
                
                # Release raster vars if they exist
                if 'out_raster' in locals(): del out_raster
                
                if os.path.exists(temp_dir):
                    shutil.rmtree(temp_dir, ignore_errors=True)
            except: pass

        except Exception as e:
            raise Exception("Gagal memotong raster: {0}".format(str(e)))

    def select_tiles(self, index_dem, aoi, messages):
        arcpy.MakeFeatureLayer_management(index_dem, "temp_index")
        arcpy.SelectLayerByLocation_management("temp_index", "INTERSECT", aoi)
        count = int(arcpy.GetCount_management("temp_index").getOutput(0))
        messages.addMessage("Jumlah tile: {0}".format(count))
        
        if count == 0:
            return 0, []
        
        tile_names = [row[0] for row in arcpy.da.SearchCursor("temp_index", ["Name"])]
        return count, tile_names

    def download_tile(self, dem_name, token, output_path, messages):
        url = "https://tanahair.indonesia.go.id/api-inageo/unduh/demnas?token={0}&filename={1}.tif".format(token, dem_name)
        
        try:
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0')
            
            if hasattr(ssl, '_create_unverified_context'):
                context = ssl._create_unverified_context()
                response = urllib2.urlopen(req, context=context, timeout=300)
            else:
                response = urllib2.urlopen(req, timeout=300)

            if response.getcode() != 200:
                raise Exception("Error HTTP {0}".format(response.getcode()))
            
            with open(output_path, 'wb') as f:
                f.write(response.read())
                
        except Exception as e:
            raise Exception("Gagal mengunduh {0}: {1}".format(dem_name, str(e)))

    def define_projection(self, raster, epsg_code, messages):
        try:
            sr = arcpy.SpatialReference(epsg_code)
            arcpy.DefineProjection_management(raster, sr)
        except Exception as e:
            raise Exception("Gagal mengatur proyeksi: {0}".format(str(e)))

    def get_crs_name(self, spatial_ref):
        name = spatial_ref.name
        if "UTM" in name:
            parts = name.split("_")
            if len(parts) >= 2:
                return parts[-2] + parts[-1]
        return name.split("_")[-1]

    def add_to_map(self, layer_path, layer_name, messages):
        try:
            # ArcMap Mapping Module
            mxd = arcpy.mapping.MapDocument("CURRENT")
            df = arcpy.mapping.ListDataFrames(mxd)[0]
            
            # Simple add layer
            layer = arcpy.mapping.Layer(layer_path)
            layer.name = layer_name
            arcpy.mapping.AddLayer(df, layer, "TOP")
            
            messages.addMessage("Layer {0} ditambahkan ke peta".format(layer_name))
        except Exception as e:
            messages.addWarningMessage("Gagal menambahkan layer ke peta: {0}".format(str(e)))

    def print_summary(self, total, success, start_time, messages):
        elapsed = time.time() - start_time
        messages.addMessage("\n=== RINGKASAN PROSES ===")
        messages.addMessage("Total tile: {0}".format(total))
        messages.addMessage("Berhasil diunduh: {0}".format(success))
        messages.addMessage("Gagal diunduh: {0}".format(total - success))
        messages.addMessage("Waktu proses: {0:.2f} detik".format(elapsed))

    def cleanup_files(self, *files):
        for f in files:
            try:
                if f and os.path.isdir(f):
                    shutil.rmtree(f, ignore_errors=True)
                elif f and arcpy.Exists(f):
                    arcpy.Delete_management(f)
            except:
                pass
                
        # Cleanup temp index layer
        try:
            if arcpy.Exists("temp_index"):
                arcpy.Delete_management("temp_index")
        except:
            pass

# ============================================================================================
# 3. DOWNLOAD RBI (ARCMAP VERSION)
# ============================================================================================

class DownloadRBIToolArcMap(object):
    def __init__(self):
        self.label = "3. Download RBI"
        self.description = "Tool untuk mengunduh data RBI"
        self.canRunInBackground = False

    def getParameterInfo(self):
        params = []

        param0 = arcpy.Parameter(
            displayName="Layer Administrasi",
            name="admin_layer",
            datatype="GPFeatureLayer",
            parameterType="Required",
            direction="Input")
        param0.filter.list = ["Polygon"]

        param1 = arcpy.Parameter(
            displayName="Field Kabupaten",
            name="kab_field",
            datatype="Field",
            parameterType="Required",
            direction="Input")
        param1.parameterDependencies = [param0.name]
        param1.filter.list = ['Text']

        param2 = arcpy.Parameter(
            displayName="Field Provinsi",
            name="prov_field",
            datatype="Field",
            parameterType="Required",
            direction="Input")
        param2.parameterDependencies = [param0.name]
        param2.filter.list = ['Text']

        param3 = arcpy.Parameter(
            displayName="Pilih Kabupaten/Kota",
            name="kabupaten",
            datatype="GPString",
            parameterType="Required",
            direction="Input")

        param4 = arcpy.Parameter(
            displayName="Provinsi (Otomatis)",
            name="provinsi",
            datatype="GPString",
            parameterType="Derived",
            direction="Output")

        param5 = arcpy.Parameter(
            displayName="Token API",
            name="token",
            datatype="GPString",
            parameterType="Required",
            direction="Input")

        param6 = arcpy.Parameter(
            displayName="Skala Peta",
            name="skala",
            datatype="GPString",
            parameterType="Required",
            direction="Input")
        param6.filter.type = "ValueList"
        param6.filter.list = ["25K", "50K"]

        param7 = arcpy.Parameter(
            displayName="Folder Output",
            name="output_folder",
            datatype="DEFolder",
            parameterType="Required",
            direction="Input")

        return [param0, param1, param2, param3, param4, param5, param6, param7]

    def updateParameters(self, parameters):
        if parameters[0].altered:
            layer = parameters[0].value
            if layer:
                self.auto_detect_fields(parameters, layer)
                kab_field = parameters[1].valueAsText
                if kab_field:
                    parameters[3].filter.list = self.get_unique_values(layer, kab_field)
                    parameters[3].enabled = True

        if parameters[3].altered and parameters[3].value:
            layer = parameters[0].value
            kab_field = parameters[1].valueAsText
            prov_field = parameters[2].valueAsText
            kabupaten = parameters[3].valueAsText
            if layer and kab_field and prov_field:
                provinsi = self.get_provinsi(layer, kab_field, prov_field, kabupaten)
                parameters[4].value = provinsi if provinsi else ""
                if not provinsi:
                    pass 

    def execute(self, parameters, messages):
        try:
            kabupaten = parameters[3].valueAsText
            provinsi = parameters[4].valueAsText
            token = parameters[5].valueAsText
            skala = parameters[6].valueAsText
            output_folder = parameters[7].valueAsText

            # --- LICENSE CHECK START (RBI) ---
            valid, msg, info = SupabaseGuard.check_license(app_name="BIG Downloader", minimum_tier="free")
            messages.addMessage(msg)
            if not valid:
                 raise Exception("Lisensi tidak valid. Hubungi admin.")
            # --- LICENSE CHECK END ---

            if not provinsi:
                raise ValueError("Provinsi tidak terdeteksi untuk kabupaten ini")

            # Use stripped token for download
            token = token.strip() if token else ""
            
            if not self.validate_token(token):
                raise ValueError("Token tidak valid. Format harus JWT (xxx.yyy.zzz)")

            self.download_rbi(token, provinsi, kabupaten, skala, output_folder, messages)

        except Exception as e:
            arcpy.AddError("Gagal eksekusi: {0}".format(str(e)))
            raise

    def download_rbi(self, token, provinsi, kabupaten, skala, output_folder, messages):
        try:
            arcpy.SetProgressor("default", "Mempersiapkan unduhan...")
            
            # Add section header
            messages.addMessage("\n=== MENGUNDUH RBI ===")
            messages.addMessage("Kabupaten: {0}".format(kabupaten))
            messages.addMessage("Provinsi: {0}".format(provinsi))

            # Using urllib.quote (from urllib, not parse)
            url = (
                "https://tanahair.indonesia.go.id/api-inageo/unduh/rbi?"
                "token={0}&"
                "prov={1}&"
                "kab={2}&"
                "skala={3}"
            ).format(
                token,
                urllib.quote(provinsi.encode('utf8')),
                urllib.quote(kabupaten.encode('utf8')),
                skala
            )

            # URL message removed as requested for cleaner output
            
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            output_file = os.path.join(
                output_folder, 
                "RBI_{0}_{1}_{2}.zip".format(
                    kabupaten.replace(' ', '_'),
                    skala,
                    timestamp
                )
            )
            
            arcpy.SetProgressor("step", "Mengunduh {0}...".format(kabupaten), 0, 100, 1)
            
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0')
            
            if hasattr(ssl, '_create_unverified_context'):
                context = ssl._create_unverified_context()
                response = urllib2.urlopen(req, context=context)
            else:
                response = urllib2.urlopen(req)

            # Content length in py2
            meta = response.info()
            file_size = 0
            # meta.getheaders in Py2.7 or just get
            if meta.get("Content-Length"):
                try:
                    file_size = int(meta.get("Content-Length"))
                except:
                    file_size = 0
            
            with open(output_file, 'wb') as f:
                block_sz = 8192
                downloaded = 0
                while True:
                    buffer = response.read(block_sz)
                    if not buffer:
                        break
                    
                    downloaded += len(buffer)
                    f.write(buffer)
                    
                    if file_size > 0:
                        progress = int((downloaded / float(file_size)) * 100)
                        arcpy.SetProgressorPosition(progress)
                        arcpy.SetProgressorLabel(
                            "Unduh {0}% ({1:.1f}MB dari {2:.1f}MB)".format(
                                progress,
                                downloaded/1024/1024.0,
                                file_size/1024/1024.0
                            )
                        )
            
            messages.addMessage("Berhasil disimpan di: {0}".format(output_file))
            
            try:
                os.startfile(output_folder)
            except:
                messages.addMessage("Buka folder output secara manual: {0}".format(output_folder))
            
        except urllib2.HTTPError as e:
            error_msg = "Error HTTP {0}: {1}".format(e.code, e.read())
            arcpy.AddError(error_msg)
            raise Exception(error_msg)
        except urllib2.URLError as e:
            arcpy.AddError("Error URL: {0}".format(str(e.reason)))
            raise
        except Exception as e:
            arcpy.AddError("Error: {0}".format(str(e)))
            raise
        finally:
            arcpy.ResetProgressor()

    def validate_token(self, token):
        return isinstance(token, basestring) and token.count('.') == 2

    def get_unique_values(self, layer, field):
        values = set()
        with arcpy.da.SearchCursor(layer, [field]) as cursor:
            for row in cursor:
                if row[0]:
                    values.add(row[0])
        return sorted(list(values))

    def get_provinsi(self, layer, kab_field, prov_field, kabupaten):
        with arcpy.da.SearchCursor(layer, [kab_field, prov_field]) as cursor:
            for row in cursor:
                val = row[0]
                # Safe unicode handling
                if isinstance(val, unicode): val = val.encode('utf-8')
                if isinstance(kabupaten, unicode): kabupaten = kabupaten.encode('utf-8')
                    
                if str(val).strip().lower() == str(kabupaten).strip().lower():
                    return row[1]
        return None

    def auto_detect_fields(self, parameters, layer):
        field_names = [f.name.lower() for f in arcpy.ListFields(layer)]

        kab_candidates = ['wadmkk', 'namobj', 'kabupaten', 'kab', 'kota']
        for candidate in kab_candidates:
            if candidate in field_names:
                parameters[1].value = candidate
                break

        prov_candidates = ['wadmpr', 'provinsi', 'prov', 'propinsi']
        for candidate in prov_candidates:
            if candidate in field_names:
                parameters[2].value = candidate
                break

# ============================================================================================
# 4. DOWNLOAD BATNAS (ARCMAP VERSION)
# ============================================================================================

class DownloadBATNASArcMap(object):
    def __init__(self):
        self.label = "4. Download BATNAS"
        self.description = "Download BATNAS elevation data and generate a mosaic automatically."
        self.canRunInBackground = False

    def getParameterInfo(self):
        params = []

        params.append(arcpy.Parameter(
            displayName="Input Grid Features",
            name="input_grid",
            datatype="GPFeatureLayer",
            parameterType="Required",
            direction="Input"))
        params[-1].filter.list = ["Polygon"]

        params.append(arcpy.Parameter(
            displayName="API Token",
            name="api_token",
            datatype="GPString",
            parameterType="Required",
            direction="Input"))

        params.append(arcpy.Parameter(
            displayName="Output Location (Folder or GDB)",
            name="output_location",
            datatype="DEWorkspace",
            parameterType="Required",
            direction="Input"))

        params.append(arcpy.Parameter(
            displayName="Output Coordinate System",
            name="output_crs",
            datatype="GPCoordinateSystem",
            parameterType="Optional",
            direction="Input"))

        params.append(arcpy.Parameter(
            displayName="Data Version",
            name="data_version",
            datatype="GPString",
            parameterType="Required",
            direction="Input"))
        params[-1].filter.list = ["1.1", "1.5"]
        params[-1].value = "1.1"

        params.append(arcpy.Parameter(
            displayName="Create Mosaic of All Tiles",
            name="create_mosaic",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input"))
        params[-1].value = True

        return params

    def isLicensed(self):
        return True

    def updateMessages(self, parameters):
        if parameters[2].value:
            out_path = parameters[2].valueAsText
            if not os.path.isdir(out_path) and not out_path.lower().endswith(".gdb"):
                parameters[2].setErrorMessage("Path must be a valid folder or file geodatabase.")
        return

    def clean_raster_name(self, name):
        # py2 re
        clean = re.sub(r'_v\d+\.\d+\.tif$', '', name, flags=re.IGNORECASE)
        clean = re.sub(r'[^a-zA-Z0-9]', '_', clean)
        return clean[:50]

    def validate_token(self, token):
        try:
            if not token or len(token.split('.')) != 3:
                return False, "Invalid token format"
            payload = token.split('.')[1]
            # padding
            payload += '=' * (-len(payload) % 4)
            decoded = json.loads(base64.b64decode(payload))
            if 'exp' in decoded:
                exp_time = datetime.fromtimestamp(decoded['exp'])
                if datetime.now() > exp_time:
                    return False, "Token expired on {0}".format(exp_time.strftime('%Y-%m-%d %H:%M:%S'))
            return True, "Token is valid"
        except Exception as e:
            return False, "Token validation error: {0}".format(str(e))

    def download_tile(self, url, temp_path):
        try:
             # Replacement for requests.get using urllib2 with chunked reading
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0')
            
            if hasattr(ssl, '_create_unverified_context'):
                context = ssl._create_unverified_context()
                response = urllib2.urlopen(req, context=context, timeout=30)
            else:
                response = urllib2.urlopen(req, timeout=30)

            with open(temp_path, 'wb') as f:
                while True:
                    chunk = response.read(1024)
                    if not chunk: break
                    f.write(chunk)
                    
            if os.path.getsize(temp_path) == 0:
                raise Exception("Downloaded file is empty")
            return True, "Download successful"
        except Exception as e:
            return False, str(e)

    def add_to_map(self, data_path):
        try:
            mxd = arcpy.mapping.MapDocument("CURRENT")
            df = arcpy.mapping.ListDataFrames(mxd)[0]
            layer = arcpy.mapping.Layer(data_path)
            arcpy.mapping.AddLayer(df, layer)
            arcpy.AddMessage("Added to map")
        except Exception as e:
            arcpy.AddWarning("Could not add to map: {0}".format(str(e)))

    def calculate_raster_stats(self, raster_path):
        try:
            arcpy.AddMessage("Calculating statistics...")
            arcpy.CheckOutExtension("Spatial") # Might be needed sometimes for stats if Raster is used, but CalculateStatistics is management.
            arcpy.CalculateStatistics_management(raster_path)
            try:
                arcpy.BuildPyramids_management(raster_path)
            except Exception as e:
                arcpy.AddWarning("BuildPyramids fallback failed: {0}".format(str(e)))
            
            # GetRasterProperties management
            min_val = arcpy.GetRasterProperties_management(raster_path, "MINIMUM").getOutput(0)
            max_val = arcpy.GetRasterProperties_management(raster_path, "MAXIMUM").getOutput(0)
            arcpy.AddMessage("Statistics: Min = {0}, Max = {1}".format(min_val, max_val))
        except Exception as e:
            arcpy.AddWarning("Could not calculate statistics: {0}".format(str(e)))

    def execute(self, parameters, messages):
        try:
            # --- LICENSE CHECK START (BATNAS) ---
            valid, msg, info = SupabaseGuard.check_license(app_name="BIG Downloader", minimum_tier="free")
            messages.addMessage(msg)
            if not valid:
                 raise Exception("Lisensi tidak valid. Hubungi admin.")
            # --- LICENSE CHECK END ---
            
            arcpy.AddMessage("Starting BATNAS download process...")

            input_grid = parameters[0].valueAsText
            api_token = parameters[1].valueAsText
            output_folder = parameters[2].valueAsText
            output_crs = parameters[3].valueAsText
            data_version = parameters[4].valueAsText
            create_mosaic = parameters[5].value

            if output_folder.lower().endswith(".gdb"):
                output_type = "GDB"
            else:
                output_type = "Folder"

            is_token_valid, token_msg = self.validate_token(api_token)
            if not is_token_valid:
                arcpy.AddError("API Token Error: {0}".format(token_msg))
                raise Exception(token_msg)
            arcpy.AddMessage("API Token validation: {0}".format(token_msg))

            if not os.path.exists(output_folder) and output_type == "Folder":
                os.makedirs(output_folder)

            downloaded_tiles = []
            failed_downloads = []
            
            arcpy.AddMessage("\n=== MENGUNDUH TILE ===")

            with arcpy.da.SearchCursor(input_grid, ["OID@", "Penamaan"]) as cursor:
                for oid, grid_name in cursor:
                    max_retries = 3
                    retry_count = 0
                    success = False
                    
                    while retry_count < max_retries and not success:
                        try:
                            # Using .format instead of f-string
                            # arcpy.AddMessage("\nProcessing OID {0}: {1} (Attempt {2})...".format(oid, grid_name, retry_count + 1))

                            filename = "BATNAS_{0}_MSL_v{1}.tif".format(grid_name, data_version)
                            clean_name = self.clean_raster_name(filename)
                            output_name = clean_name + ("" if output_type == "GDB" else ".tif")
                            output_path = os.path.join(output_folder, output_name)

                            # quote from urllib
                            url = "https://tanahair.indonesia.go.id/api-inageo/unduh/batnas?token={0}&filename={1}".format(api_token, urllib.quote(filename))
                            temp_path = os.path.join(arcpy.env.scratchFolder, filename)


                            success_down, msg = self.download_tile(url, temp_path)
                            if not success_down:
                                raise Exception(msg)

                            arcpy.AddMessage("Berhasil: {0}".format(grid_name))

                            # Add temp file to list for mosaicking (don't save to output folder yet)
                            if output_crs:
                                # Project to temp location
                                proj_temp = os.path.join(arcpy.env.scratchFolder, "{0}_proj.tif".format(filename))
                                arcpy.ProjectRaster_management(temp_path, proj_temp, output_crs, pixel_type="32_BIT_FLOAT")
                                downloaded_tiles.append(proj_temp)
                                try: os.remove(temp_path)
                                except: pass
                            else:
                                downloaded_tiles.append(temp_path)
                            
                            success = True 

                        except Exception as e:
                            retry_count += 1
                            error_msg = "Attempt {0} failed for OID {1}: {2}".format(retry_count, oid, str(e))
                            arcpy.AddWarning(error_msg)
                            
                            if retry_count >= max_retries:
                                failed_downloads.append("OID {0} - {1}".format(oid, str(e)))
                                arcpy.AddError("Failed processing OID {0} after {1} attempts".format(oid, max_retries))
                            else:
                                wait_time = 5 * retry_count
                                arcpy.AddMessage("Waiting {0} seconds before retrying...".format(wait_time))
                                time.sleep(wait_time)
                            
                            if 'temp_path' in locals() and os.path.exists(temp_path):
                                try: os.remove(temp_path)
                                except: pass

            # Mosaic
            if create_mosaic and downloaded_tiles:
                arcpy.AddMessage("\n=== MEMBUAT MOSAIK ===")
                mosaic_name = "BATNAS_Mosaic"
                mosaic_path = (
                    os.path.join(output_folder, mosaic_name) 
                    if output_type == "GDB" 
                    else os.path.join(output_folder, mosaic_name + ".tif")
                )
                
                # Check list length, MosaicToNewRaster might need semicolon string in py2
                input_rasters_str = ";".join(downloaded_tiles)

                arcpy.MosaicToNewRaster_management(
                    input_rasters=input_rasters_str,
                    output_location=output_folder,
                    raster_dataset_name_with_extension=os.path.basename(mosaic_path),
                    pixel_type="32_BIT_FLOAT",
                    number_of_bands=1,
                    mosaic_method="LAST",
                    mosaic_colormap_mode="FIRST"
                )

                arcpy.AddMessage("Mosaic berhasil dibuat: {0}".format(mosaic_path))
                arcpy.AddMessage("Menghitung statistik...")
                self.calculate_raster_stats(mosaic_path)
                self.add_to_map(mosaic_path)
                
                # Cleanup: Delete all temp tiles after mosaic is created
                arcpy.AddMessage("Membersihkan file sementara...")
                for tile_path in downloaded_tiles:
                    try:
                        if arcpy.Exists(tile_path):
                            arcpy.Delete_management(tile_path)
                    except:
                        pass

            arcpy.AddMessage("\n=== RINGKASAN PROSES ===")
            arcpy.AddMessage("Berhasil diunduh: {0}".format(len(downloaded_tiles)))
            if failed_downloads:
                arcpy.AddWarning("Gagal diunduh: {0}".format(len(failed_downloads)))
                for e in failed_downloads:
                    arcpy.AddWarning(" - {0}".format(e))

            arcpy.AddMessage("Process completed successfully.")

        except Exception as e:
            arcpy.AddError("Tool failed: {0}".format(str(e)))
            raise


# ============================================================================================
# 5. DOWNLOAD BATAS WILAYAH (ARCMAP VERSION - Python 2.7)
# ============================================================================================

class DownloadBatasWilayahArcMap(object):
    """Download batas wilayah administrasi dari layanan REST BIG (ArcMap)."""

    URL_KABUPATEN = "https://geoservices.big.go.id/rbi/rest/services/BATASWILAYAH/Administrasi_AR_KabKota_50K/MapServer/0"
    URL_KECAMATAN = "https://geoservices.big.go.id/rbi/rest/services/BATASWILAYAH/Administrasi_AR_Kecamatan_10K/MapServer/0"
    URL_DESA      = "https://geoservices.big.go.id/rbi/rest/services/BATASWILAYAH/Administrasi_AR_KelDesa_10K/MapServer/0"

    PROVINSI_LIST = sorted([
        "Aceh", "Bali", "Banten", "Bengkulu", "DKI Jakarta",
        "Daerah Istimewa Yogyakarta", "Gorontalo", "Jambi",
        "Jawa Barat", "Jawa Tengah", "Jawa Timur",
        "Kalimantan Barat", "Kalimantan Selatan", "Kalimantan Tengah",
        "Kalimantan Timur", "Kalimantan Utara",
        "Kepulauan Bangka Belitung", "Kepulauan Riau", "Lampung",
        "Maluku", "Maluku Utara", "Nusa Tenggara Barat", "Nusa Tenggara Timur",
        "Papua", "Papua Barat", "Papua Barat Daya", "Papua Pegunungan",
        "Papua Selatan", "Papua Tengah", "Riau",
        "Sulawesi Barat", "Sulawesi Selatan", "Sulawesi Tengah",
        "Sulawesi Tenggara", "Sulawesi Utara",
        "Sumatera Barat", "Sumatera Selatan", "Sumatera Utara"
    ])

    def __init__(self):
        self.label = "5. Download Batas Wilayah"
        self.description = (
            "Download batas wilayah administrasi Indonesia (Kabupaten/Kota, "
            "Kecamatan, Kelurahan/Desa) langsung dari layanan REST BIG."
        )
        self.canRunInBackground = False

    def getParameterInfo(self):
        p0 = arcpy.Parameter(
            displayName="Tingkat Wilayah (Skala Data)",
            name="tingkat_wilayah",
            datatype="GPString",
            parameterType="Required",
            direction="Input")
        p0.filter.type = "ValueList"
        p0.filter.list = [
            "Kabupaten/Kota (RBI 1:50K)",
            "Kecamatan (RBI 1:10K)",
            "Kelurahan/Desa (RBI 1:10K)"
        ]
        p0.value = "Kabupaten/Kota (RBI 1:50K)"

        p1 = arcpy.Parameter(
            displayName="Filter Provinsi (kosongkan = semua)",
            name="filter_provinsi",
            datatype="GPString",
            parameterType="Optional",
            direction="Input")
        p1.filter.type = "ValueList"
        p1.filter.list = self.PROVINSI_LIST

        p2 = arcpy.Parameter(
            displayName="Filter Kabupaten/Kota (kosongkan = semua)",
            name="filter_kabupaten",
            datatype="GPString",
            parameterType="Optional",
            direction="Input")
        p2.filter.type = "ValueList"
        p2.filter.list = []
        p2.enabled = False

        p3 = arcpy.Parameter(
            displayName="Filter Kecamatan (kosongkan = semua)",
            name="filter_kecamatan",
            datatype="GPString",
            parameterType="Optional",
            direction="Input")
        p3.filter.type = "ValueList"
        p3.filter.list = []
        p3.enabled = False

        p4 = arcpy.Parameter(
            displayName="Output Folder / Geodatabase",
            name="output_folder",
            datatype="DEWorkspace",
            parameterType="Required",
            direction="Input")
        try:
            if hasattr(arcpy.env, 'scratchGDB'):
                p4.value = arcpy.env.scratchGDB
        except Exception:
            pass

        p5 = arcpy.Parameter(
            displayName="Output Name",
            name="output_name",
            datatype="GPString",
            parameterType="Required",
            direction="Input")
        p5.value = ""

        return [p0, p1, p2, p3, p4, p5]

    def isLicensed(self):
        return True

    def updateParameters(self, parameters):
        level_raw = parameters[0].valueAsText or "Kabupaten/Kota (RBI 1:50K)"
        if "Kabupaten" in level_raw:
            level = "Kabupaten/Kota"
        elif "Kecamatan" in level_raw:
            level = "Kecamatan"
        else:
            level = "Kelurahan/Desa"

        prov = parameters[1].valueAsText
        kab = parameters[2].valueAsText

        # Show/hide cascading filters
        if level == "Kabupaten/Kota":
            parameters[1].enabled = True
            parameters[2].enabled = False
            parameters[3].enabled = False
        elif level == "Kecamatan":
            parameters[1].enabled = True
            parameters[2].enabled = True
            parameters[3].enabled = False
        else:
            parameters[1].enabled = True
            parameters[2].enabled = True
            parameters[3].enabled = True

        # Fetch Kabupaten list
        if prov and (parameters[1].altered or not parameters[2].filter.list):
            try:
                kab_list = self._get_distinct(self.URL_KABUPATEN, "WADMKK",
                                              "WADMPR='{0}'".format(prov))
                if kab_list != parameters[2].filter.list:
                    parameters[2].filter.list = kab_list
                    if parameters[1].altered:
                        parameters[2].value = None
                        parameters[3].filter.list = []
                        parameters[3].value = None
            except Exception:
                pass

        # Fetch Kecamatan list
        if prov and kab and (parameters[2].altered or not parameters[3].filter.list):
            try:
                kec_list = self._get_distinct(self.URL_KECAMATAN, "WADMKC",
                                              "WADMPR='{0}' AND WADMKK='{1}'".format(prov, kab))
                if kec_list != parameters[3].filter.list:
                    parameters[3].filter.list = kec_list
                    if parameters[2].altered:
                        parameters[3].value = None
            except Exception:
                pass

        # Reset when level changes
        if parameters[0].altered:
            if level == "Kabupaten/Kota":
                parameters[2].filter.list = []
                parameters[2].value = None
                parameters[3].filter.list = []
                parameters[3].value = None
            elif level == "Kecamatan":
                parameters[3].filter.list = []
                parameters[3].value = None

        # Auto-suggest output name
        current_name = parameters[5].valueAsText or ""
        if not current_name or current_name.startswith("WADM_"):
            level_short = {
                "Kabupaten/Kota": "KK",
                "Kecamatan": "KC",
                "Kelurahan/Desa": "KD"
            }.get(level, level)
            parts = ["WADM", level_short]
            if prov:
                parts.append(re.sub(r'[^A-Za-z0-9]', '_', prov))
            kec = parameters[3].valueAsText
            if kab:
                parts.append(re.sub(r'[^A-Za-z0-9]', '_', kab))
            if kec:
                parts.append(re.sub(r'[^A-Za-z0-9]', '_', kec))
            parameters[5].value = "_".join(parts)
        return

    def updateMessages(self, parameters):
        level_raw = parameters[0].valueAsText
        if "Kabupaten" in (level_raw or ""):
            level = "Kabupaten/Kota"
        elif "Kecamatan" in (level_raw or ""):
            level = "Kecamatan"
        else:
            level = "Kelurahan/Desa"
        prov = parameters[1].valueAsText
        kab = parameters[2].valueAsText

        if level == "Kelurahan/Desa" and not prov:
            parameters[1].setWarningMessage(
                "Tanpa filter provinsi, semua data desa/kelurahan Indonesia "
                "(~80.000+ fitur) akan diunduh. Disarankan pilih provinsi."
            )
        elif level == "Kelurahan/Desa" and prov and not kab:
            parameters[2].setWarningMessage(
                "Tanpa filter kabupaten, semua desa/kelurahan di provinsi ini "
                "akan diunduh. Proses mungkin membutuhkan waktu cukup lama."
            )
        elif level == "Kecamatan" and not prov:
            parameters[1].setWarningMessage(
                "Tanpa filter provinsi, semua kecamatan Indonesia "
                "(~7.000+ fitur) akan diunduh."
            )
        return

    # ------------------------------------------------------------------
    # Helper: get distinct (Python 2.7 urllib2)
    def _get_distinct(self, base_url, field, where="1=1"):
        try:
            params = urllib.urlencode({
                "where": where,
                "outFields": field,
                "returnGeometry": "false",
                "returnDistinctValues": "true",
                "orderByFields": field,
                "f": "json"
            })
            url = "{0}/query?{1}".format(base_url, params)
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0')

            if hasattr(ssl, '_create_unverified_context'):
                ctx = ssl._create_unverified_context()
                resp = urllib2.urlopen(req, context=ctx, timeout=30)
            else:
                resp = urllib2.urlopen(req, timeout=30)

            data = json.loads(resp.read())
            return sorted(set(
                (f["attributes"].get(field) or "").strip()
                for f in data.get("features", [])
                if f["attributes"].get(field)
            ))
        except Exception:
            return []

    # Helper: download all features with pagination + retry (Python 2.7)
    def _query_all(self, base_url, where="1=1"):
        all_features = []
        base_json = {}
        offset = 0
        batch = 1000
        max_retries = 3

        while True:
            params = urllib.urlencode({
                "where": where,
                "outFields": "*",
                "f": "json",
                "resultOffset": offset,
                "resultRecordCount": batch,
                "orderByFields": "objectid"
            })
            url = "{0}/query?{1}".format(base_url, params)

            for attempt in range(1, max_retries + 1):
                try:
                    req = urllib2.Request(url)
                    req.add_header('User-Agent', 'Mozilla/5.0')
                    if hasattr(ssl, '_create_unverified_context'):
                        ctx = ssl._create_unverified_context()
                        resp = urllib2.urlopen(req, context=ctx, timeout=120)
                    else:
                        resp = urllib2.urlopen(req, timeout=120)
                    data = json.loads(resp.read())
                    break
                except Exception as e:
                    if attempt == max_retries:
                        raise Exception(
                            "Gagal mengunduh batch offset={0} setelah {1} percobaan: {2}".format(
                                offset, max_retries, str(e)))
                    arcpy.AddMessage(
                        "  Percobaan {0}/{1} gagal, mencoba ulang...".format(
                            attempt, max_retries))
                    time.sleep(5 * attempt)

            if not base_json and "geometryType" in data:
                base_json = {
                    "geometryType": data.get("geometryType", "esriGeometryPolygon"),
                    "spatialReference": data.get("spatialReference", {"wkid": 4326}),
                    "fields": data.get("fields", [])
                }

            batch_features = data.get("features", [])
            all_features.extend(batch_features)
            arcpy.AddMessage("  Fetched {0} features...".format(len(all_features)))

            if len(batch_features) < batch:
                break
            offset += batch

        base_json["features"] = all_features
        return base_json

    # ------------------------------------------------------------------
    def execute(self, parameters, messages):
        valid, msg, info = SupabaseGuard.check_license(
            app_name="BIG Downloader ArcMap", minimum_tier="free", show_machine_id=False)
        messages.addMessage(msg)
        if not valid:
            raise Exception("Lisensi tidak valid. Hubungi admin.")

        level_raw = parameters[0].valueAsText
        if "Kabupaten" in (level_raw or ""):
            level = "Kabupaten/Kota"
        elif "Kecamatan" in (level_raw or ""):
            level = "Kecamatan"
        else:
            level = "Kelurahan/Desa"

        prov = parameters[1].valueAsText
        kab = parameters[2].valueAsText
        kec = parameters[3].valueAsText
        out_folder = parameters[4].valueAsText
        out_name = parameters[5].valueAsText

        safe_name = re.sub(r'[^A-Za-z0-9_]', '_', out_name)

        if level == "Kabupaten/Kota":
            svc_url = self.URL_KABUPATEN
            parts = ["1=1"]
            if prov:
                parts.append("WADMPR='{0}'".format(prov))
            where = " AND ".join(parts)
        elif level == "Kecamatan":
            svc_url = self.URL_KECAMATAN
            parts = ["1=1"]
            if prov:
                parts.append("WADMPR='{0}'".format(prov))
            if kab:
                parts.append("WADMKK='{0}'".format(kab))
            where = " AND ".join(parts)
        else:
            svc_url = self.URL_DESA
            parts = ["1=1"]
            if prov:
                parts.append("WADMPR='{0}'".format(prov))
            if kab:
                parts.append("WADMKK='{0}'".format(kab))
            if kec:
                parts.append("WADMKC='{0}'".format(kec))
            where = " AND ".join(parts)

        arcpy.AddMessage("\n=== DOWNLOAD BATAS WILAYAH (BIG) ===")
        arcpy.AddMessage("Tingkat   : {0}".format(level))
        arcpy.AddMessage("Provinsi  : {0}".format(prov or "Semua"))
        arcpy.AddMessage("Kabupaten : {0}".format(kab or "-"))
        arcpy.AddMessage("Kecamatan : {0}".format(kec or "-"))
        arcpy.AddMessage("Mengunduh data dari server BIG...")

        esri_json_data = self._query_all(svc_url, where)
        total = len(esri_json_data.get("features", []))

        if total == 0:
            raise Exception("Tidak ada data ditemukan dengan filter yang dipilih.")

        arcpy.AddMessage("Total fitur: {0}".format(total))

        tmp_dir = arcpy.env.scratchFolder or tempfile.gettempdir()
        tmp_json = os.path.join(tmp_dir, "{0}_temp.json".format(safe_name))

        with open(tmp_json, "w") as f:
            json.dump(esri_json_data, f)

        arcpy.AddMessage("Konversi ke Feature Class...")

        out_path = os.path.join(out_folder, safe_name)
        arcpy.JSONToFeatures_conversion(tmp_json, out_path)

        try:
            os.remove(tmp_json)
        except Exception:
            pass

        arcpy.AddMessage("Berhasil! Data tersimpan di: {0}".format(out_path))

        try:
            mxd = arcpy.mapping.MapDocument("CURRENT")
            df = arcpy.mapping.ListDataFrames(mxd)[0]
            layer = arcpy.mapping.Layer(out_path)
            layer.name = safe_name
            arcpy.mapping.AddLayer(df, layer, "TOP")
            arcpy.AddMessage("Layer berhasil ditambahkan ke peta.")
        except Exception as e:
            arcpy.AddWarning("Gagal menambahkan layer ke peta: {0}".format(str(e)))

        arcpy.AddMessage("=== SELESAI ===")

