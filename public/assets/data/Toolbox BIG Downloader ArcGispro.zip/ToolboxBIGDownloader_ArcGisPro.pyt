# -*- coding: utf-8 -*-
"""
Toolbox untuk mengunduh tile DEMNAS (Digital Elevation Model Nasional) Indonesia
Versi ArcGIS Pro
"""

import arcpy
import os
import urllib.request
import urllib.error
import urllib.request as urllib2
import ssl
import time
import re
import random
import webbrowser
import json
from datetime import datetime, timezone
import uuid
import platform
import getpass
import urllib.parse
from arcpy.sa import ExtractByMask
from arcpy.sa import *
import requests
import re
from urllib.parse import quote
import sys
import traceback
import base64


# ============================================================================================
# TOOLBOX UTAMA
# ============================================================================================


# ===================================================================================
#  SUPABASE LICENSE GUARD (FINAL CLEAN VERSION)
# ===================================================================================
class SupabaseGuard:
    SUPABASE_URL = "https://mbfzmvlivyuajmxrecne.supabase.co"
    SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1iZnptdmxpdnl1YWpteHJlY25lIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU0NzgwODQsImV4cCI6MjA4MTA1NDA4NH0.sZltNY30ww2Hb_oopiVDcvXnZRehWRvK2jZZU5MO64s"
    TABLE_NAME = "licenses"
    
    # KONTAK ADMIN
    ADMIN_NAME = "Ardi Abu Ridho"
    ADMIN_WA   = "+62 822-5476-0769"
    ADMIN_WA   = "+62 822-5476-0769"
    VERSION    = "4.0.0"
    
    @staticmethod
    def get_machine_id():
        import tempfile
        import getpass
        import os
        import subprocess
        import platform
        import uuid
        import base64
        import ctypes
        import hashlib
        
        app_data = os.environ.get('LOCALAPPDATA', tempfile.gettempdir())
        target_dir = os.path.join(app_data, 'ESRI')
        if not os.path.exists(target_dir):
            try:
                os.makedirs(target_dir)
            except Exception:
                target_dir = tempfile.gettempdir()
                
        id_file = os.path.join(target_dir, ".sys_core_cfg_v2.db")
        
        # 1. Try Load Existing Sticky Identity (Obfuscated)
        if os.path.exists(id_file):
            try:
                with open(id_file, "r") as f:
                    encoded_id = f.read().strip()
                if encoded_id: 
                    # Decode base64 and reverse to get original ID
                    decoded = base64.b64decode(encoded_id).decode('utf-8')[::-1]
                    return decoded
            except Exception: pass

        def get_hw_info(wmic_cmd, ps_cmd):
            try:
                si = None
                if os.name == 'nt':
                    si = subprocess.STARTUPINFO()
                    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                
                try:
                    output = subprocess.check_output('wmic ' + wmic_cmd, shell=True, startupinfo=si).decode().strip()
                    lines = output.split(os.linesep)
                    if len(lines) > 1:
                        val = lines[1].strip()
                        if val and val.lower() not in ['none', 'to be filled by o.e.m.', '0', 'default string', 'unknown']:
                            return val
                except Exception: pass

                try:
                    ps_full_cmd = 'powershell -NoProfile -ExecutionPolicy Bypass -Command "' + ps_cmd + '"'
                    output = subprocess.check_output(ps_full_cmd, shell=True, startupinfo=si).decode().strip()
                    if output and output.lower() not in ['none', '0', 'unknown']:
                        return output
                except Exception: pass
            except Exception: pass
            return None

        uid = None
        
        # 1. Try Machine UUID
        uuid_val = get_hw_info('csproduct get uuid', 'Get-CimInstance Win32_ComputerSystemProduct | Select-Object -ExpandProperty UUID')
        if uuid_val and uuid_val != 'FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF':
            uid = uuid_val.replace('-', '')[:12].lower()

        # 2. Try BIOS Serial Number
        if not uid:
            bios_val = get_hw_info('bios get serialnumber', 'Get-CimInstance Win32_BIOS | Select-Object -ExpandProperty SerialNumber')
            if bios_val:
                uid = hashlib.md5(bios_val.encode()).hexdigest()[:12].lower()

        # 3. Try Baseboard Serial Number
        if not uid:
            bb_val = get_hw_info('baseboard get serialnumber', 'Get-CimInstance Win32_BaseBoard | Select-Object -ExpandProperty SerialNumber')
            if bb_val:
                uid = hashlib.md5(bb_val.encode()).hexdigest()[:12].lower()

        # 4. Fallback: Stable MAC Address (All adapters sorted)
        if not uid:
            try:
                import re
                macs = []
                if os.name == 'nt':
                    try:
                        output = subprocess.check_output('getmac /fo csv /v', shell=True).decode()
                        found = re.findall(r'([0-9A-F]{2}-[0-9A-F]{2}-[0-9A-F]{2}-[0-9A-F]{2}-[0-9A-F]{2}-[0-9A-F]{2})', output, re.I)
                        for m in found:
                            clean_m = m.replace('-', '').lower()
                            if clean_m != '000000000000': macs.append(clean_m)
                    except Exception: pass
                
                if not macs:
                    node = uuid.getnode()
                    macs.append(hex(node)[2:].rstrip('L').lower())

                if macs:
                    uid = sorted(macs)[0][:12]
            except Exception: pass

        if not uid:
            uid = "unknown_device"

        # Save identity (Obfuscated & Hidden)
        if uid and uid != "unknown_device":
            try:
                # Reverse string and Base64 encode
                obfuscated = base64.b64encode(uid[::-1].encode('utf-8')).decode('utf-8')
                with open(id_file, "w") as f:
                    f.write(obfuscated)
                # Hide file in Windows
                if platform.system() == 'Windows':
                    ctypes.windll.kernel32.SetFileAttributesW(id_file, 0x02) # FILE_ATTRIBUTE_HIDDEN
            except Exception: pass
            
        return uid

    @staticmethod
    def make_request(url, method="GET", data=None):
        headers = {
            "apikey": SupabaseGuard.SUPABASE_KEY,
            "Authorization": f"Bearer {SupabaseGuard.SUPABASE_KEY}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }
        req_data = json.dumps(data).encode('utf-8') if data else None
        req = urllib.request.Request(url, data=req_data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req) as response:
                if response.status in [200, 201, 204]:
                    resp_body = response.read().decode('utf-8')
                    return json.loads(resp_body) if resp_body else []
                return None
        except:
            return None

    @staticmethod
    def format_status_box(status, expiry, days_left, app_name, tier, machine_id=None):
        border = "=" * 60
        nl = chr(10)
        
        expiry_text = "Seumur Hidup"
        if expiry:
            expiry_text = f"{expiry} (Sisa {days_left} hari)"
            
        lines = []
        lines.append(nl + border)
        lines.append(" STATUS LISENSI (AHZA TOOLS)")
        lines.append(border)
        lines.append(f" Aplikasi     : {app_name}")
        lines.append(f" Versi        : {SupabaseGuard.VERSION}")
        lines.append(f" Status       : {status.upper()}")
        lines.append(f" Tipe Paket   : {tier.upper()}")
        lines.append(f" Masa Aktif   : {expiry_text}")
        
        if machine_id:
            lines.append(f" Machine ID   : {machine_id}")
        lines.append("")
        lines.append(" Hubungi Admin jika ada kendala:")
        lines.append(f" {SupabaseGuard.ADMIN_NAME} ({SupabaseGuard.ADMIN_WA})")
        lines.append(border + nl)
        
        return nl.join(lines)

    @staticmethod
    def check_license(app_name="BIG Downloader", minimum_tier="free", show_machine_id=True):
        try:
            safe_app = "".join(c if c.isalnum() else "_" for c in app_name).lower()
            minimum_tier = minimum_tier.lower()
            
            # Tier Levels Definition
            # 1 = Free (Contour, Slope, Morphology)
            # 2 = Basic (Grid, Planting Points, SPH)
            # 3 = Pro (AI, Harvest Route, Terrace)
            tier_levels = {"free": 1, "basic": 2, "pro": 3}
            # required_level = tier_levels.get(minimum_tier, 2) # Not used in override
            

            machine_id = SupabaseGuard.get_machine_id()
            mid_display = machine_id if show_machine_id else None
            base_url = SupabaseGuard.SUPABASE_URL
            table = SupabaseGuard.TABLE_NAME
            
            # Query Existing
            query = urllib.parse.urlencode({
                "machine_id": f"eq.{machine_id}",
                "app_name": f"eq.{safe_app}",
                "select": "*"
            })
            url = f"{base_url}/rest/v1/{table}?{query}"
            
            data = SupabaseGuard.make_request(url, "GET")
            if data is None: 
                return False, "[ERROR] Gagal koneksi internet ke server lisensi.", {}
            
            final_data = None
            
            if not data:
                # REGISTER NEW (Default Tier: basic)
                try:
                    hostname = platform.node()
                    username = getpass.getuser()
                    auto_client = f"{hostname} ({username}) [ArcPro]"
                except:
                    auto_client = "Unknown PC [ArcPro]"

                payload = {
                    "machine_id": machine_id,
                    "app_name": safe_app,
                    "last_check": datetime.now(timezone.utc).isoformat(),
                    "tier": "free",       # FORCE FREE (LIFETIME)
                    "status": "active",   # FORCE ACTIVE
                    "expiry_date": None,  # FORCE NO EXPIRY
                    "expiry_date": None,  # FORCE NO EXPIRY
                    "client_name": auto_client,
                    "version": SupabaseGuard.VERSION
                }
                post_url = f"{base_url}/rest/v1/{table}"
                new_data = SupabaseGuard.make_request(post_url, "POST", payload)
                if not new_data: return False, "Gagal Registrasi Trial.", {}
                final_data = new_data[0]
            else:
                final_data = data[0]

                # --- OLD LOGIC REMOVED FROM HERE ---

                # --- AUTO-UPDATE LOGIC: TRIAL -> ACTIVE FREE LIFETIME ---
                current_status = final_data.get("status", "").lower()
                if current_status in ["trial", "banned", "expired"]: # Added extra statuses just in case
                    try:
                        patch_params = {
                            "machine_id": f"eq.{machine_id}", 
                            "app_name": f"eq.{safe_app}"
                        }
                        patch_query = urllib.parse.urlencode(patch_params)
                        patch_url = f"{base_url}/rest/v1/{table}?{patch_query}"
                        
                        patch_data = {
                            "status": "active",
                            "tier": "free",
                            "expiry_date": None,
                            "tier": "free",
                            "expiry_date": None,
                            "last_check": datetime.now(timezone.utc).isoformat(),
                            "version": SupabaseGuard.VERSION
                        }
                        SupabaseGuard.make_request(patch_url, "PATCH", patch_data)
                        
                        # Update local variables for display
                        final_data["status"] = "active"
                        final_data["tier"] = "free"
                        final_data["expiry_date"] = None
                    except:
                        pass
                else:
                    # Normal heartbeat
                    q_upd = urllib.parse.urlencode({"machine_id": f"eq.{machine_id}", "app_name": f"eq.{safe_app}"})
                    url_upd = f"{base_url}/rest/v1/{table}?{q_upd}"
                    
                    # Auto-detect client info for analytics
                    try:
                        hostname = platform.node()
                        username = getpass.getuser()
                        auto_client = f"{hostname} ({username}) [ArcPro]"
                    except:
                        auto_client = "Unknown PC [ArcPro]"

                    SupabaseGuard.make_request(url_upd, "PATCH", {
                        "last_check": datetime.now(timezone.utc).isoformat(),
                        "version": SupabaseGuard.VERSION,
                        "client_name": auto_client
                    })

            # =========================================================================
            # GLOBAL CLEANUP: ENFORCE NULL EXPIRY FOR FREE TIER (HANDLES DB TRIGGER)
            # =========================================================================
            _tier = final_data.get("tier", "").lower()
            _status = final_data.get("status", "").lower()
            _expiry = final_data.get("expiry_date")
            
            # Catch:
            # 1. Free tier but has expiry date (DB trigger artifact)
            # 2. Trial status (failed update)
            # 3. Pro tier (we want everyone to be Free Lifetime)
            should_cleanup = False
            if _tier == "free" and _expiry is not None: should_cleanup = True
            if _status == "trial": should_cleanup = True
            if _tier == "pro": should_cleanup = True
            
            if should_cleanup:
                try:
                    # Construct Paramater dengan aman
                    patch_params = {
                        "machine_id": f"eq.{machine_id}", 
                        "app_name": f"eq.{safe_app}"
                    }
                    patch_query = urllib.parse.urlencode(patch_params)
                    patch_url = f"{base_url}/rest/v1/{table}?{patch_query}"
                    
                    # Force update: expiry_date -> null
                    patch_data = {
                        "status": "active",
                        "tier": "free",
                        "expiry_date": None,
                        "last_check": datetime.now(timezone.utc).isoformat()
                    }
                    
                    # Kirim Request
                    SupabaseGuard.make_request(patch_url, "PATCH", patch_data)
                    
                    # Update local variable agar UI langsung refresh jadi "Lifetime"
                    final_data["status"] = "active"
                    final_data["tier"] = "free"
                    final_data["expiry_date"] = None
                    
                except Exception as cleanup_err:
                    # Log error silent tapi update local data agar user tetap bisa pakai
                    # print(f"Cleanup Error: {cleanup_err}") 
                    pass
            # =========================================================================

            status = final_data.get("status", "trial").lower()
            tier = final_data.get("tier", "basic").lower()
            expiry = final_data.get("expiry_date")
            days_left = 0
            
            info = {
                "tier": tier,
                "status": status,
                "expiry": expiry
            }

            if status == "banned": 
                return False, SupabaseGuard.format_status_box("BANNED", expiry, 0, safe_app, tier, mid_display), info
            
            # --- 3-TIER LOGIC IMPLEMENTATION (STRICT MATRIX) ---
            user_level = 1 # Default to Free (Safe Fallback)
            
            # 1. TRIAL LOGIC
            if status == "trial":
                 if expiry:
                    try:
                        exp_date = datetime.strptime(expiry, "%Y-%m-%d")
                        now_date = datetime.now()
                        days_left = (exp_date - now_date).days
                        info["days_left"] = days_left
                        
                        if days_left > 0: # CHANGED to days_left logic
                            # ACTIVE TRIAL -> PRO TIER (Level 3 - Max Access)
                            user_level = 3 
                        else:
                            # EXPIRED TRIAL -> FREE TIER (Level 1)
                            user_level = 1 
                            status = "TRIAL EXPIRED (FREE MODE)" 
                    except: 
                        # Fallback for error date parsing
                        user_level = 1
                 else:
                    # No expiry date on trial? assume active trial -> PRO
                    user_level = 3
            
            # 2. ACTIVE / PAID LOGIC
            elif status == "active":
                 # Use their actual purchased tier
                 user_level = tier_levels.get(tier, 1)
            
            # 3. EXPIRED PAID LOGIC
            elif status == "expired":
                 # Expired Subscription -> Revert to FREE TIER (Level 1)
                 user_level = 1
                 status = "SUBSCRIPTION EXPIRED (FREE MODE)"
            
            # --- FINAL CHECK ---
            req_lev = tier_levels.get(minimum_tier, 1) # Default to Free (1)
            
            if user_level < req_lev:
                  req_tier_name = minimum_tier.upper()
                  user_tier_name = "FREE"
                  if user_level == 2: user_tier_name = "BASIC"
                  elif user_level == 3: user_tier_name = "PRO"
                  
                  msg_tier = SupabaseGuard.format_status_box(status, expiry, days_left, safe_app, user_tier_name, mid_display)
                  
                  # Special Message
                  detail_msg = f"\n[ACCESS DENIED] Fitur ini eksklusif untuk paket {req_tier_name}."
                  detail_msg += f"\nPaket Anda saat ini: {user_tier_name}."
                  
                  return False, msg_tier + detail_msg, info
            
            # -------------------
            
            msg = SupabaseGuard.format_status_box(status, expiry, days_left, safe_app, tier, mid_display)
            return True, msg, info

        except Exception as e:
            return False, f"License Logic Error: {str(e)}", {}

class Toolbox(object):
    def __init__(self):
        """Mendefinisikan toolbox DEMNAS Downloader untuk ArcGIS Pro."""
        self.label = "BIG Downloader Tools (v4.0.0)"
        self.alias = "BIGDownloaderTools_v2"
        self.tools = [LoginDEMNAS,DownloadDemnasPro,DownloadRBIToolPro,DownloadBATNAS,DownloadBatasWilayah]

# ============================================================================================
# 1. LOGIN DEMNAS
# ============================================================================================

class LoginDEMNAS(object):
    def __init__(self):
        self.label = "1. Login INA-Geoportal"
        self.description = "Buka halaman login DEMNAS dan ikuti panduan untuk mengambil token."

    def getParameterInfo(self):
        panduan = arcpy.Parameter(
            displayName="Panduan Mengambil Token DEMNAS",
            name="panduan_token",
            datatype="GPString",
            parameterType="Optional",  # Agar muncul di UI
            direction="Input"
        )
        panduan.value = (
            "=== PANDUAN MENGAMBIL TOKEN DEMNAS ===\n\n"
            "1. Klik tombol [Run] di bawah untuk membuka halaman login.\n"
            "2. Tekan [F12] untuk membuka Developer Tools.\n"
            "3. Masuk ke tab [Network].\n"
            "4. Login dengan akun DEMNAS Anda.\n"
            "5. Kembali ke tab [Network], lalu pada Header/Field Name cari {;}signin, dan klik.\n"
            "6. Pada bagian kanan akan muncul Header,Payload, Preview dan Response.\n"
            "7. Ambil nilai 'accessToken:'  dari bagian Preview atau Response.\n"
            "8. Pastikan Anda sudah logout saat menjalankan tools ini.\n\n"
            "Gunakan token tersebut di Tool #2 (Unduh DEMNAS)."
        )
        return [panduan]

    def isLicensed(self):
        return True

    def updateParameters(self, parameters):
        """Set default output location to project's default geodatabase"""
        return
        return

    def updateMessages(self, parameters):
        return

    def execute(self, parameters, messages):
        # --- LICENSE CHECK START (LOGIN) ---
        valid, msg, info = SupabaseGuard.check_license(app_name="BIG Downloader ArcPro", minimum_tier="free", show_machine_id=False)
        messages.addMessage(msg)
        if not valid:
             raise Exception("Lisensi tidak valid. Hubungi admin.")
        # --- LICENSE CHECK END ---

        url = "https://tanahair.indonesia.go.id/portal-web/login"
        webbrowser.open(url)
        messages.addMessage("Browser telah dibuka. Silakan ikuti panduan di kolom parameter.")

# ============================================================================================
# 2. DOWNLOAD DEMNAS (ARCGIS PRO VERSION WITH SUMMARY)
# ============================================================================================

import arcpy
import os
import time
import urllib.request
import urllib.error
import ssl
import tempfile
import shutil

class DownloadDemnasPro(object):
    def __init__(self):
        """Define the tool (tool name is the class name)."""
        self.label = "2. Download DEMNAS (Mosaic)"
        self.description = "Download tile DEMNAS with improved clipping and output format"
        self.canRunInBackground = False

    def getParameterInfo(self):
        """Define parameter definitions"""
        params = [
            # Parameter 0: DEMNAS index grid layer
            arcpy.Parameter(
                displayName="DEMNAS Index Grid",
                name="index_dem",
                datatype="GPFeatureLayer",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 1: Area of Interest (AOI)
            arcpy.Parameter(
                displayName="Area of Interest (AOI)",
                name="aoi",
                datatype="GPFeatureLayer",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 2: API Token
            arcpy.Parameter(
                displayName="API Token",
                name="token",
                datatype="GPString",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 3: Output Location
            arcpy.Parameter(
                displayName="Output Location (Folder or Geodatabase)",
                name="output_location",
                datatype="DEWorkspace",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 4: Output Name
            arcpy.Parameter(
                displayName="Output Name (without extension)",
                name="output_name",
                datatype="GPString",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 5: Clip with AOI
            arcpy.Parameter(
                displayName="Clip DEM with AOI?",
                name="clip_dem",
                datatype="GPBoolean",
                parameterType="Required",
                direction="Input"),
            
            # Parameter 6: Output Coordinate System
            arcpy.Parameter(
                displayName="Output Coordinate System",
                name="output_crs",
                datatype="GPSpatialReference",
                parameterType="Optional",
                direction="Input"),

            # Parameter 7: Buffer Distance
            arcpy.Parameter(
                displayName="Buffer Distance (meters)",
                name="buffer_distance",
                datatype="GPDouble",
                parameterType="Optional",
                direction="Input")
        ]
        
        # Set default values
        params[4].value = "DEMNAS_Output"
        params[5].value = True
        params[7].value = 100.0
        
        return params

    def isLicensed(self):
        """Set whether tool is licensed to execute."""
        return True

    def updateParameters(self, parameters):
        """Modify the values and properties of parameters before internal
        validation is performed."""
        # Dynamic Enable/Disable Buffer
        if parameters[5].value is True:  # Clip Checked
            parameters[7].enabled = True
        else:
            parameters[7].enabled = False
            
        # Set default output location to project's default geodatabase
        if parameters[3].value is None and not parameters[3].altered:
            try:
                aprx = arcpy.mp.ArcGISProject("CURRENT")
                default_gdb = aprx.defaultGeodatabase
                if default_gdb and arcpy.Exists(default_gdb):
                    parameters[3].value = default_gdb
                else:
                    # Fallback to scratch GDB
                    if hasattr(arcpy.env, 'scratchGDB'):
                         parameters[3].value = arcpy.env.scratchGDB
            except:
                # Ultimate fallback
                if hasattr(arcpy.env, 'scratchGDB'):
                    parameters[3].value = arcpy.env.scratchGDB
        return

    def updateMessages(self, parameters):
        """Modify the messages created by internal validation."""
        return
        

    def execute(self, parameters, messages):
        """The source code of the tool."""
        start_time = time.time()

        # Get parameters    
        index_dem = parameters[0].valueAsText
        aoi = parameters[1].valueAsText
        token = parameters[2].valueAsText
        output_location = parameters[3].valueAsText
        output_name = parameters[4].valueAsText
        clip_dem = parameters[5].value
        output_crs = parameters[6].value
        buffer_dist = parameters[7].value
        
        # --- LICENSE CHECK START (DEMNAS) ---
        valid, msg, info = SupabaseGuard.check_license(app_name="BIG Downloader ArcPro", minimum_tier="free")
        messages.addMessage(msg)
        if not valid:
             raise Exception("Lisensi tidak valid. Hubungi admin.")
        # --- LICENSE CHECK END ---

        # Initialize variables
        mosaic_path = None
        temp_files = []
        final_outputs = []
        
        try:
            # Validate inputs
            if not token or len(token.strip()) < 10:
                raise ValueError("Token API tidak valid atau kosong!")

            if not arcpy.Exists(output_location):
                raise ValueError(f"Lokasi output tidak ditemukan: {output_location}")

            # Setup environment
            arcpy.env.overwriteOutput = True
            arcpy.env.compression = "LZW"
            
            # 1. Select tiles intersecting with AOI
            count, tile_names = self.select_tiles(index_dem, aoi, messages)
            if count == 0:
                return

            # 2. Download all tiles with basic processing
            messages.addMessage("\n=== MENGUNDUH TILE ===")
            tile_paths = []
            for dem_name in tile_names:
                try:
                    temp_dir = tempfile.mkdtemp()
                    temp_tif = os.path.join(temp_dir, f"{dem_name}.tif")
                    self.download_tile(dem_name, token, temp_tif, messages)
                    
                    if arcpy.Exists(temp_tif):
                        # Basic processing - define projection and remove negatives
                        self.define_projection(temp_tif, 4326, messages)
                        corrected_tif = os.path.join(temp_dir, f"{dem_name}_corrected.tif")
                        arcpy.sa.Con(arcpy.Raster(temp_tif) < 0, 0, arcpy.Raster(temp_tif)).save(corrected_tif)
                        
                        tile_paths.append(corrected_tif)
                        # temp_files.extend([temp_tif, corrected_tif]) # No longer needed if we delete dir
                        messages.addMessage(f"Berhasil: {dem_name}")
                    
                    # Track directory for cleanup
                    temp_files.append(temp_dir)
                    
                except Exception as e:
                    messages.addWarningMessage(f"Gagal memproses {dem_name}: {str(e)}")

            if not tile_paths:
                raise Exception("Tidak ada tile yang berhasil diproses")

            # 3. Simple and reliable mosaicking
            messages.addMessage("\n=== MEMBUAT MOSAIK ===")
            mosaic_dir = tempfile.mkdtemp()
            temp_files.append(mosaic_dir)
            
            # Method: Direct mosaic with BLEND method
            mosaic_path = os.path.join(mosaic_dir, "DEMNAS_Mosaic.tif")
            cell_size = arcpy.Describe(tile_paths[0]).meanCellWidth
            
            arcpy.MosaicToNewRaster_management(
                input_rasters=tile_paths,
                output_location=mosaic_dir,
                raster_dataset_name_with_extension="DEMNAS_Mosaic.tif",
                coordinate_system_for_the_raster=arcpy.SpatialReference(4326),
                pixel_type="32_BIT_FLOAT",
                cellsize=cell_size,
                number_of_bands=1,
                mosaic_method="BLEND",  # Best for edge blending
                mosaic_colormap_mode="FIRST"
            )
            temp_files.append(mosaic_path)

            # 4. Create final output
            is_gdb = output_location.lower().endswith('.gdb')
            
            # Determine suffix
            suffix = ""
            if clip_dem:
                suffix += "_clip"
            
            if output_crs and output_crs.factoryCode != 4326:
                suffix += "_utm"

            output_path = os.path.join(output_location, f"{output_name}{suffix}".replace(" ", "_"))
            if not is_gdb:
                output_path += ".tif"

            # 5. Optional projection
            if output_crs and output_crs.factoryCode != 4326:
                messages.addMessage("\n=== PROYEKSI OUTPUT ===")
                # If we project, we overwrite the previous output or create a new one?
                # User logic implies single output file with stacked suffixes.
                # So we project FROM mosaic/temp TO the final output_path 
                
                # If we are clipping, output_path is already written by clip_raster ??
                # Wait, clip_raster writes to output_path.
                # If we project, we should project THE RESULT.
                
                # Logic Refinement:
                # If Clip: Mosaic -> Clip -> Output
                # If Project: Output -> Project -> Output (Overwrite) OR Mosaic -> Project -> Clip -> Output
                
                # Simplest Flow:
                # Mosaic (WGS84) -> [Clip?] -> Temp_WGS84 -> [Project?] -> Final Output
                
                pass # Projection handled in flow below
            
            # RESTRUCTURED FLOW:
            # 1. Mosaic created at mosaic_path (WGS84)
            # 2. If Clip: Clip mosaic_path -> temp_clipped_path
            # 3. If Project: Project (mosaic_path OR temp_clipped_path) -> final_output_path
            # 4. If neither: Copy mosaic_path -> final_output_path

            current_raster = mosaic_path
            
            if clip_dem:
                messages.addMessage(f"\n=== MEMOTONG SESUAI AOI (BUFFER: {buffer_dist}m) ===")
                temp_clipped = os.path.join(mosaic_dir, "temp_clipped.tif")
                self.clip_raster(current_raster, aoi, temp_clipped, messages, buffer_dist)
                current_raster = temp_clipped
                
            if output_crs and output_crs.factoryCode != 4326:
                messages.addMessage(f"\n=== PROYEKSI OUTPUT ({output_crs.name}) ===")
                arcpy.ProjectRaster_management(
                    current_raster,
                    output_path,
                    output_crs,
                    resampling_type="BILINEAR"
                )
            else:
                # Just copy final result
                if current_raster != output_path:
                    arcpy.CopyRaster_management(current_raster, output_path)
             
            final_outputs.append(output_path)

            # 6. Add to map with simplified symbology
            for output in final_outputs:
                output_name = os.path.basename(output).split('.')[0]
                self.add_to_map(output, output_name, messages)
                
                # Simplified symbology application
                try:
                    aprx = arcpy.mp.ArcGISProject("CURRENT")
                    for lyr in aprx.activeMap.listLayers(output_name):
                        if lyr.isRasterLayer:
                            sym = lyr.symbology
                            if hasattr(sym, 'colorizer'):
                                # Use the default symbology without forcing type
                                sym.colorizer.stretchType = "MinimumMaximum"
                                if len(aprx.listColorRamps("Elevation #1")) > 0:
                                    sym.colorizer.colorRamp = aprx.listColorRamps("Elevation #1")[0]
                                lyr.symbology = sym
                except Exception as sym_error:
                    messages.addWarningMessage(f"Couldn't set symbology: {str(sym_error)}")

            # 7. Print summary
            self.print_summary(count, len(tile_paths), start_time, messages)

        except Exception as e:
            arcpy.AddError(f"ERROR: {str(e)}")
            raise
        finally:
            # Clean up all temporary files
            self.cleanup_files(*temp_files)


    def clip_raster(self, input_raster, aoi, output_path, messages, buffer_dist=100.0):
        """Clip raster with AOI using a more robust approach."""
        try:
            # Create a temporary directory in Scratch workspace for better management
            # Try to resolve valid scratch path
            scratch_path = arcpy.env.scratchFolder or arcpy.env.scratchGDB or tempfile.gettempdir()
            # If scratchGDB is returned (it's a .gdb path), we need folder.
            if str(scratch_path).endswith('.gdb'):
                 scratch_path = os.path.dirname(scratch_path)
                 
            # Create unique temp folder
            unique_name = f"tmp{int(time.time())}"
            temp_dir = os.path.join(scratch_path, unique_name)
            if not os.path.exists(temp_dir):
                os.makedirs(temp_dir)
                
            # Create temporary paths with no spaces
            
            # Create temporary paths with no spaces
            temp_aoi = os.path.join(temp_dir, "aoi_feature.shp")
            temp_buffered_aoi = os.path.join(temp_dir, "aoi_buffered.shp")
            temp_output = os.path.join(temp_dir, "output_clip.tif")
            
            # Export AOI to shapefile if it's not already
            if arcpy.Describe(aoi).catalogPath.endswith('.shp'):
                temp_aoi = aoi
            else:
                arcpy.FeatureClassToFeatureClass_conversion(aoi, temp_dir, "aoi_feature.shp")
            
            # Apply buffer if buffer_dist > 0
            clip_feature = temp_aoi
            if buffer_dist and buffer_dist > 0:
                messages.addMessage("Membuffer AOI sebesar {0} meter...".format(buffer_dist))
                arcpy.Buffer_analysis(
                    in_features=temp_aoi,
                    out_feature_class=temp_buffered_aoi,
                    buffer_distance_or_field="{0} Meters".format(buffer_dist),
                    dissolve_option="ALL"
                )
                clip_feature = temp_buffered_aoi
            
            # messages.addMessage("Membuat file temporary untuk proses clipping...")
            
            # Try multiple clipping methods with fallbacks
            try:
                # Method 1: ExtractByMask with Spatial Analyst
                if arcpy.CheckExtension("Spatial") == "Available":
                    arcpy.CheckOutExtension("Spatial")
                    # Use input_raster directly
                    out_raster = arcpy.sa.ExtractByMask(input_raster, clip_feature)
                    out_raster.save(temp_output)
                    arcpy.CheckInExtension("Spatial")
                    messages.addMessage("Berhasil memotong menggunakan ExtractByMask")
                else:
                    raise Exception("Spatial Analyst tidak tersedia")
                    
            except Exception as e1:
                messages.addWarningMessage(f"ExtractByMask gagal: {str(e1)}. Mencoba Clip_management...")
                
                # Method 2: Clip Management
                try:
                    arcpy.Clip_management(
                        in_raster=input_raster, # Use input_raster directly
                        rectangle="#",
                        out_raster=temp_output,
                        in_template_dataset=clip_feature,
                        nodata_value="#",
                        clipping_geometry="ClippingGeometry",
                        maintain_clipping_extent="MAINTAIN_EXTENT"
                    )
                    messages.addMessage("Berhasil memotong menggunakan Clip Management")
                    
                except Exception as e2:
                    # Method 3: Feature to Raster alternative
                    messages.addWarningMessage(f"Clip Management gagal: {str(e2)}. Mencoba metode alternatif...")
                    try:
                        # Convert AOI to raster first
                        temp_aoi_raster = os.path.join(temp_dir, "aoi_raster.tif")
                        arcpy.FeatureToRaster_conversion(
                            clip_feature, 
                            arcpy.ListFields(clip_feature)[0].name,  # Use first field
                            temp_aoi_raster, 
                            cellsize=arcpy.Describe(input_raster).meanCellWidth
                        )
                        
                        # Extract by mask with the rasterized AOI
                        out_raster = arcpy.sa.ExtractByMask(input_raster, temp_aoi_raster)
                        out_raster.save(temp_output)
                        messages.addMessage("Berhasil memotong menggunakan metode alternatif")
                        
                    except Exception as e3:
                        raise Exception(f"Semua metode pemotongan gagal: {str(e3)}")
            
            # Copy final output to destination
            # If output_path is in GDB, CopyRaster handles it.
            # If output_path is TIF, CopyRaster handles it.
            if arcpy.Exists(output_path):
                 arcpy.Delete_management(output_path)
                 
            arcpy.CopyRaster_management(temp_output, output_path)
            # messages.addMessage(f"Output final disimpan di: {output_path}") # Removed to avoid confusion if called internally
            
        except Exception as e:
            raise Exception(f"Gagal memotong raster: {str(e)}")
        finally:
            # Clean up temporary files
            try:
                # Force release locks
                if 'temp_output' in locals() and arcpy.Exists(temp_output):
                    arcpy.Delete_management(temp_output)
                if 'temp_aoi_raster' in locals() and arcpy.Exists(temp_aoi_raster):
                    arcpy.Delete_management(temp_aoi_raster)
                
                if os.path.exists(temp_dir):
                    shutil.rmtree(temp_dir, ignore_errors=True)
            except:
                pass

    def select_tiles(self, index_dem, aoi, messages):
        """Select tiles intersecting with AOI."""
        arcpy.MakeFeatureLayer_management(index_dem, "temp_index")
        arcpy.SelectLayerByLocation_management("temp_index", "INTERSECT", aoi)
        count = int(arcpy.GetCount_management("temp_index").getOutput(0))
        messages.addMessage(f"Jumlah tile: {count}")
        
        if count == 0:
            return 0, []
        
        tile_names = [row[0] for row in arcpy.da.SearchCursor("temp_index", ["Name"])]
        return count, tile_names

    def download_tile(self, dem_name, token, output_path, messages):
        """Download tile from DEMNAS API."""
        url = f"https://tanahair.indonesia.go.id/api-inageo/unduh/demnas?token={token}&filename={dem_name}.tif"
        
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=300) as response:
                if response.status != 200:
                    raise Exception(f"Error HTTP {response.status}")
                
                with open(output_path, 'wb') as f:
                    f.write(response.read())
        except Exception as e:
            raise Exception(f"Gagal mengunduh {dem_name}: {str(e)}")

    def define_projection(self, raster, epsg_code, messages):
        """Define projection for raster."""
        try:
            sr = arcpy.SpatialReference(epsg_code)
            arcpy.DefineProjection_management(raster, sr)
        except Exception as e:
            raise Exception(f"Gagal mengatur proyeksi: {str(e)}")

    def get_crs_name(self, spatial_ref):
        """Get short name for CRS."""
        name = spatial_ref.name
        if "UTM" in name:
            return name.split("_")[-2] + name.split("_")[-1]
        return name.split("_")[-1]

    def add_to_map(self, layer_path, layer_name, messages):
        """Add layer to map."""
        try:
            aprx = arcpy.mp.ArcGISProject("CURRENT")
            active_map = aprx.activeMap
            
            # Remove existing layer with same name
            for lyr in active_map.listLayers():
                if lyr.name == layer_name:
                    active_map.removeLayer(lyr)
            
            active_map.addDataFromPath(layer_path)
            messages.addMessage(f"Layer {layer_name} ditambahkan ke peta")
        except Exception as e:
            messages.addWarningMessage(f"Gagal menambahkan layer ke peta: {str(e)}")

    def print_summary(self, total, success, start_time, messages):
        """Print processing summary."""
        elapsed = time.time() - start_time
        messages.addMessage("\n=== RINGKASAN PROSES ===")
        messages.addMessage(f"Total tile: {total}")
        messages.addMessage(f"Berhasil diunduh: {success}")
        messages.addMessage(f"Gagal diunduh: {total - success}")
        messages.addMessage(f"Waktu proses: {elapsed:.2f} detik")

    def cleanup_files(self, *files):
        """Clean up temporary files and directories."""
        for f in files:
            try:
                if f and os.path.isdir(f):
                    shutil.rmtree(f, ignore_errors=True)
                elif f and arcpy.Exists(f):
                    arcpy.Delete_management(f)
            except:
                pass
        
        # Cleanup temp index layer
        try:
            if arcpy.Exists("temp_index"):
                arcpy.Delete_management("temp_index")
        except:
            pass

# ============================================================================================
# 3. DOWNLOAD RBI (ARCGIS PRO VERSION)
# ============================================================================================

class DownloadRBIToolPro(object):
    def __init__(self):
        """Tool untuk mengunduh data RBI (Rupabumi Indonesia)."""
        self.label = "3. Download RBI"
        self.description = "Tool untuk mengunduh data RBI"
        self.canRunInBackground = False

    def getParameterInfo(self):
        params = []

        param0 = arcpy.Parameter(
            displayName="Layer Administrasi",
            name="admin_layer",
            datatype="GPFeatureLayer",
            parameterType="Required",
            direction="Input")
        param0.filter.list = ["Polygon"]

        param1 = arcpy.Parameter(
            displayName="Field Kabupaten",
            name="kab_field",
            datatype="Field",
            parameterType="Required",
            direction="Input")
        param1.parameterDependencies = [param0.name]
        param1.filter.list = ['Text']

        param2 = arcpy.Parameter(
            displayName="Field Provinsi",
            name="prov_field",
            datatype="Field",
            parameterType="Required",
            direction="Input")
        param2.parameterDependencies = [param0.name]
        param2.filter.list = ['Text']

        param3 = arcpy.Parameter(
            displayName="Pilih Kabupaten/Kota",
            name="kabupaten",
            datatype="GPString",
            parameterType="Required",
            direction="Input")

        param4 = arcpy.Parameter(
            displayName="Provinsi (Otomatis)",
            name="provinsi",
            datatype="GPString",
            parameterType="Derived",
            direction="Output")

        param5 = arcpy.Parameter(
            displayName="Token API",
            name="token",
            datatype="GPString",
            parameterType="Required",
            direction="Input")

        param6 = arcpy.Parameter(
            displayName="Skala Peta",
            name="skala",
            datatype="GPString",
            parameterType="Required",
            direction="Input")
        param6.filter.type = "ValueList"
        param6.filter.list = ["25K", "50K"]

        param7 = arcpy.Parameter(
            displayName="Folder Output",
            name="output_folder",
            datatype="DEFolder",
            parameterType="Required",
            direction="Input")

        return [param0, param1, param2, param3, param4, param5, param6, param7]

    def updateParameters(self, parameters):
        if parameters[0].altered:
            layer = parameters[0].value
            if layer:
                self.auto_detect_fields(parameters, layer)
                kab_field = parameters[1].valueAsText
                if kab_field:
                    parameters[3].filter.list = self.get_unique_values(layer, kab_field)
                    parameters[3].enabled = True

        if parameters[3].altered and parameters[3].value:
            layer = parameters[0].value
            kab_field = parameters[1].valueAsText
            prov_field = parameters[2].valueAsText
            kabupaten = parameters[3].valueAsText
            if layer and kab_field and prov_field:
                provinsi = self.get_provinsi(layer, kab_field, prov_field, kabupaten)
                parameters[4].value = provinsi if provinsi else ""
                if not provinsi:
                    arcpy.AddWarning("Provinsi tidak terdeteksi!")

    def execute(self, parameters, messages):
        try:
            kabupaten = parameters[3].valueAsText
            provinsi = parameters[4].valueAsText
            token = parameters[5].valueAsText
            skala = parameters[6].valueAsText
            output_folder = parameters[7].valueAsText

            # --- LICENSE CHECK START (RBI) ---
            valid, msg, info = SupabaseGuard.check_license(app_name="BIG Downloader ArcPro", minimum_tier="free")
            messages.addMessage(msg)
            if not valid:
                 raise Exception("Lisensi tidak valid. Hubungi admin.")
            # --- LICENSE CHECK END ---

            if not provinsi:
                raise ValueError("Provinsi tidak terdeteksi untuk kabupaten ini")

            if not self.validate_token(token):
                raise ValueError("Token tidak valid. Format harus JWT (xxx.yyy.zzz)")

            self.download_rbi(token, provinsi, kabupaten, skala, output_folder, messages)

        except Exception as e:
            arcpy.AddError("Gagal eksekusi: {0}".format(str(e)))
            raise

    def download_rbi(self, token, provinsi, kabupaten, skala, output_folder, messages):
        """Fungsi untuk mengunduh data RBI dari API."""
        try:
            # Set progressor untuk menampilkan progress
            arcpy.SetProgressor("default", "Mempersiapkan unduhan...")
            
            # Add section header
            messages.addMessage("\n=== MENGUNDUH RBI ===")
            messages.addMessage("Kabupaten: {0}".format(kabupaten))
            messages.addMessage("Provinsi: {0}".format(provinsi))

            # Bangun URL untuk mengunduh RBI dengan encoding yang aman
            url = (
                "https://tanahair.indonesia.go.id/api-inageo/unduh/rbi?"
                "token={0}&"
                "prov={1}&"
                "kab={2}&"
                "skala={3}"
            ).format(
                token,  # Token API
                urllib.parse.quote(provinsi.encode('utf8')),  # Provinsi (encoded)
                urllib.parse.quote(kabupaten.encode('utf8')),  # Kabupaten (encoded)
                skala  # Skala peta
            )

            # URL message removed as requested for cleaner output
            
            # Buat nama file output dengan timestamp
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            output_file = os.path.join(
                output_folder, 
                "RBI_{0}_{1}_{2}.zip".format(
                    kabupaten.replace(' ', '_'),  # Ganti spasi dengan underscore
                    skala,  # Skala peta
                    timestamp  # Timestamp
                )
            )
            
            # Set progressor untuk menampilkan progress unduhan
            arcpy.SetProgressor("step", "Mengunduh {0}...".format(kabupaten), 0, 100, 1)
            
            # Buat request HTTP
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0')  # Tambahkan header User-Agent
            response = urllib.request.urlopen(req)  # Buka koneksi
            
            # Cek ukuran file dari header Content-Length
            meta = response.info()
            file_size = 0
            if meta.get_all("Content-Length"):
                try:
                    file_size = int(meta.get_all("Content-Length")[0])
                except:
                    file_size = 0
            
            # Simpan file dengan progress tracking
            with open(output_file, 'wb') as f:
                block_sz = 8192  # Ukuran buffer untuk membaca data
                downloaded = 0  # Jumlah byte yang sudah diunduh
                while True:
                    buffer = response.read(block_sz)  # Baca data
                    if not buffer:  # Jika tidak ada data lagi, keluar dari loop
                        break
                    
                    downloaded += len(buffer)  # Tambahkan ke total yang diunduh
                    f.write(buffer)  # Tulis ke file
                    
                    # Update progress jika tahu ukuran total file
                    if file_size > 0:
                        progress = int((downloaded / float(file_size)) * 100)
                        arcpy.SetProgressorPosition(progress)  # Update progress bar
                        arcpy.SetProgressorLabel(
                            "Unduh {0}% ({1:.1f}MB dari {2:.1f}MB)".format(
                                progress,
                                downloaded/1024/1024.0,  # Konversi ke MB
                                file_size/1024/1024.0    # Konversi ke MB
                            )
                        )
            
            messages.addMessage("Berhasil disimpan di: {0}".format(output_file))
            
            # Coba buka folder output secara otomatis (Windows)
            try:
                os.startfile(output_folder)
            except Exception:
                messages.addMessage("Buka folder output secara manual: {0}".format(output_folder))
            
        except urllib.error.HTTPError as e:
            # Tangani error HTTP
            error_msg = "Error HTTP {0}: {1}".format(e.code, e.read())
            arcpy.AddError(error_msg)
            raise Exception(error_msg)
        except urllib.error.URLError as e:
            # Tangani error URL
            arcpy.AddError("Error URL: {0}".format(str(e.reason)))
            raise
        except Exception as e:
            # Tangani error umum
            arcpy.AddError("Error: {0}".format(str(e)))
            raise
        finally:
            # Reset progressor setelah selesai
            arcpy.ResetProgressor()


    def validate_token(self, token):
        return isinstance(token, str) and token.count('.') == 2

    def get_unique_values(self, layer, field):
        values = set()
        with arcpy.da.SearchCursor(layer, [field]) as cursor:
            for row in cursor:
                if row[0]:
                    values.add(row[0])
        return sorted(list(values))

    def get_provinsi(self, layer, kab_field, prov_field, kabupaten):
        with arcpy.da.SearchCursor(layer, [kab_field, prov_field]) as cursor:
            for row in cursor:
                if str(row[0]).strip().lower() == str(kabupaten).strip().lower():
                    return row[1]
        return None

    def auto_detect_fields(self, parameters, layer):
        field_names = [f.name.lower() for f in arcpy.ListFields(layer)]

        kab_candidates = ['wadmkk', 'namobj', 'kabupaten', 'kab', 'kota']
        for candidate in kab_candidates:
            if candidate in field_names:
                parameters[1].value = candidate
                break

        prov_candidates = ['wadmpr', 'provinsi', 'prov', 'propinsi']
        for candidate in prov_candidates:
            if candidate in field_names:
                parameters[2].value = candidate
                break

# ============================================================================================
# 4. DOWNLOAD BATNAS
# ============================================================================================

# -*- coding: utf-8 -*-
import arcpy
import os
import re
import requests
import json
import base64
from urllib.parse import quote
from datetime import datetime

class DownloadBATNAS(object):
    def __init__(self):
        self.label = "4. Download BATNAS"
        self.description = "Download BATNAS elevation data and generate a mosaic automatically."
        self.canRunInBackground = False

    def getParameterInfo(self):
        params = []

        params.append(arcpy.Parameter(
            displayName="Input Grid Features",
            name="input_grid",
            datatype="GPFeatureLayer",
            parameterType="Required",
            direction="Input"))
        params[-1].filter.list = ["Polygon"]

        params.append(arcpy.Parameter(
            displayName="API Token",
            name="api_token",
            datatype="GPString",
            parameterType="Required",
            direction="Input"))

        params.append(arcpy.Parameter(
            displayName="Output Location (Folder or GDB)",
            name="output_location",
            datatype="DEWorkspace",
            parameterType="Required",
            direction="Input"))

        params.append(arcpy.Parameter(
            displayName="Output Coordinate System",
            name="output_crs",
            datatype="GPCoordinateSystem",
            parameterType="Optional",
            direction="Input"))

        params.append(arcpy.Parameter(
            displayName="Data Version",
            name="data_version",
            datatype="GPString",
            parameterType="Required",
            direction="Input"))
        params[-1].filter.list = ["1.1", "1.5"]
        params[-1].value = "1.1"

        params.append(arcpy.Parameter(
            displayName="Create Mosaic of All Tiles",
            name="create_mosaic",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input"))
        params[-1].value = True

        return params

    def isLicensed(self):
        return True

    def updateParameters(self, parameters):
        """Set default output location to project's default geodatabase"""
        if parameters[2].value is None and not parameters[2].altered:
            try:
                aprx = arcpy.mp.ArcGISProject("CURRENT")
                default_gdb = aprx.defaultGeodatabase
                if default_gdb and arcpy.Exists(default_gdb):
                    parameters[2].value = default_gdb
                else:
                     if hasattr(arcpy.env, 'scratchGDB'):
                         parameters[2].value = arcpy.env.scratchGDB
            except:
                 if hasattr(arcpy.env, 'scratchGDB'):
                    parameters[2].value = arcpy.env.scratchGDB
        return

    def updateMessages(self, parameters):
        if parameters[2].value:
            out_path = parameters[2].valueAsText
            if not os.path.isdir(out_path) and not out_path.lower().endswith(".gdb"):
                parameters[2].setErrorMessage("Path must be a valid folder or file geodatabase.")
        return

    def clean_raster_name(self, name):
        clean = re.sub(r'_v\d+\.\d+\.tif$', '', name, flags=re.IGNORECASE)
        clean = re.sub(r'[^a-zA-Z0-9]', '_', clean)
        return clean[:50]

    def validate_token(self, token):
        try:
            if not token or len(token.split('.')) != 3:
                return False, "Invalid token format"
            payload = token.split('.')[1]
            payload += '=' * (-len(payload) % 4)
            decoded = json.loads(base64.b64decode(payload).decode('utf-8'))
            if 'exp' in decoded:
                exp_time = datetime.fromtimestamp(decoded['exp'])
                if datetime.now() > exp_time:
                    return False, f"Token expired on {exp_time.strftime('%Y-%m-%d %H:%M:%S')}"
            return True, "Token is valid"
        except Exception as e:
            return False, f"Token validation error: {str(e)}"

    def download_tile(self, url, temp_path):
        try:
            with requests.get(url, stream=True, timeout=30) as response:
                response.raise_for_status()
                with open(temp_path, 'wb') as f:
                    for chunk in response.iter_content(1024):
                        f.write(chunk)
            if os.path.getsize(temp_path) == 0:
                raise Exception("Downloaded file is empty")
            return True, "Download successful"
        except Exception as e:
            return False, str(e)

    def add_to_map(self, data_path):
        try:
            aprx = arcpy.mp.ArcGISProject("CURRENT")
            active_map = aprx.activeMap
            active_map.addDataFromPath(data_path)
            arcpy.AddMessage("Added to map")
        except Exception as e:
            arcpy.AddWarning(f"Could not add to map: {str(e)}")

    def calculate_raster_stats(self, raster_path):
        try:
            arcpy.AddMessage("Calculating statistics...")
            arcpy.management.CalculateStatistics(raster_path)
            try:
                arcpy.management.BuildPyramids(raster_path)
            except Exception as e:
                arcpy.AddWarning(f"BuildPyramids fallback failed: {str(e)}")
            min_val = arcpy.management.GetRasterProperties(raster_path, "MINIMUM").getOutput(0)
            max_val = arcpy.management.GetRasterProperties(raster_path, "MAXIMUM").getOutput(0)
            arcpy.AddMessage(f"Statistics: Min = {min_val}, Max = {max_val}")
        except Exception as e:
            arcpy.AddWarning(f"Could not calculate statistics: {str(e)}")

    def execute(self, parameters, messages):
        try:
            # --- LICENSE CHECK START (BATNAS) ---
            valid, msg, info = SupabaseGuard.check_license(app_name="BIG Downloader ArcPro", minimum_tier="free")
            messages.addMessage(msg)
            if not valid:
                 raise Exception("Lisensi tidak valid. Hubungi admin.")
            # --- LICENSE CHECK END ---
            
            arcpy.AddMessage("Starting BATNAS download process...")

            input_grid = parameters[0].valueAsText
            api_token = parameters[1].valueAsText
            output_folder = parameters[2].valueAsText
            output_crs = parameters[3].valueAsText
            data_version = parameters[4].valueAsText
            create_mosaic = parameters[5].value

            # Deteksi otomatis output type
            if output_folder.lower().endswith(".gdb"):
                output_type = "GDB"
            else:
                output_type = "Folder"

            is_token_valid, token_msg = self.validate_token(api_token)
            if not is_token_valid:
                arcpy.AddError(f"API Token Error: {token_msg}")
                raise Exception(token_msg)
            arcpy.AddMessage(f"API Token validation: {token_msg}")

            if not os.path.exists(output_folder) and output_type == "Folder":
                os.makedirs(output_folder)

            downloaded_tiles = []
            failed_downloads = []
            
            arcpy.AddMessage("\n=== MENGUNDUH TILE ===")

            with arcpy.da.SearchCursor(input_grid, ["OID@", "Penamaan"]) as cursor:
                for oid, grid_name in cursor:
                    max_retries = 3
                    retry_count = 0
                    success = False
                    
                    while retry_count < max_retries and not success:
                        try:
                            # arcpy.AddMessage(f"\nProcessing OID {oid}: {grid_name} (Attempt {retry_count + 1})...")

                            filename = f"BATNAS_{grid_name}_MSL_v{data_version}.tif"
                            
                            # Save to TEMP folder instead of output folder
                            temp_path = os.path.join(arcpy.env.scratchFolder, filename)

                            url = f"https://tanahair.indonesia.go.id/api-inageo/unduh/batnas?token={api_token}&filename={quote(filename)}"

                            # Download tile
                            success, msg = self.download_tile(url, temp_path)
                            if not success:
                                raise Exception(msg)

                            arcpy.AddMessage(f"Berhasil: {grid_name}")

                            # Add temp file to list for mosaicking
                            if output_crs:
                                # Project to temp location
                                proj_temp = os.path.join(arcpy.env.scratchFolder, f"{filename}_proj.tif")
                                arcpy.management.ProjectRaster(temp_path, proj_temp, output_crs, pixel_type="32_BIT_FLOAT")
                                downloaded_tiles.append(proj_temp)
                                os.remove(temp_path)  # Remove unprojected temp
                            else:
                                downloaded_tiles.append(temp_path)

                            success = True  # Mark as successful

                        except Exception as e:
                            retry_count += 1
                            error_msg = f"Attempt {retry_count} failed for OID {oid}: {str(e)}"
                            arcpy.AddWarning(error_msg)
                            
                            if retry_count >= max_retries:
                                failed_downloads.append(f"OID {oid} - {str(e)}")
                                arcpy.AddError(f"Failed processing OID {oid} after {max_retries} attempts")
                            else:
                                # Tunggu sebentar sebelum mencoba lagi
                                import time
                                wait_time = 5 * retry_count  # Exponential backoff
                                arcpy.AddMessage(f"Waiting {wait_time} seconds before retrying...")
                                time.sleep(wait_time)
                            
                            if 'temp_path' in locals() and os.path.exists(temp_path):
                                try: 
                                    os.remove(temp_path)
                                except: 
                                    pass

            # Create mosaic
            if create_mosaic and downloaded_tiles:
                arcpy.AddMessage("\n=== MEMBUAT MOSAIK ===")
                
                # Fix ERROR 999999: Disable parallel processing for stability
                arcpy.env.parallelProcessingFactor = "0"
                
                mosaic_name = "BATNAS_Mosaic"
                mosaic_path = (
                    os.path.join(output_folder, mosaic_name) 
                    if output_type == "GDB" 
                    else os.path.join(output_folder, mosaic_name + ".tif")
                )

                # Get properties from first tile to ensure match
                try:
                    desc = arcpy.Describe(downloaded_tiles[0])
                    pt_map = {
                        'U1':'1_BIT', 'U2':'2_BIT', 'U4':'4_BIT',
                        'U8':'8_BIT_UNSIGNED', 'S8':'8_BIT_SIGNED',
                        'U16':'16_BIT_UNSIGNED', 'S16':'16_BIT_SIGNED',
                        'U32':'32_BIT_UNSIGNED', 'S32':'32_BIT_SIGNED',
                        'F32':'32_BIT_FLOAT', 'F64':'64_BIT_DOUBLE'
                    }
                    pixel_type = pt_map.get(desc.pixelType, "32_BIT_FLOAT")
                    bands = desc.bandCount
                    # Use output_crs if available, otherwise first tile's SRS
                    sr = output_crs if output_crs else desc.spatialReference
                except Exception as e:
                    arcpy.AddWarning(f"Warning deriving raster props: {e}. Using defaults.")
                    pixel_type = "32_BIT_FLOAT"
                    bands = 1
                    sr = output_crs

                arcpy.management.MosaicToNewRaster(
                    input_rasters=downloaded_tiles,
                    output_location=output_folder,
                    raster_dataset_name_with_extension=os.path.basename(mosaic_path),
                    coordinate_system_for_the_raster=sr,
                    pixel_type=pixel_type,
                    number_of_bands=bands,
                    mosaic_method="LAST"
                )

                arcpy.AddMessage(f"Mosaic berhasil dibuat: {mosaic_path}")
                arcpy.AddMessage("Menghitung statistik...")
                self.calculate_raster_stats(mosaic_path)
                self.add_to_map(mosaic_path)
                
                # Cleanup: Delete all temp tiles after mosaic is created
                arcpy.AddMessage("Membersihkan file sementara...")
                for tile_path in downloaded_tiles:
                    try:
                        if arcpy.Exists(tile_path):
                            arcpy.Delete_management(tile_path)
                    except:
                        pass

            arcpy.AddMessage("\n=== RINGKASAN PROSES ===")
            arcpy.AddMessage(f"Berhasil diunduh: {len(downloaded_tiles)}")
            if failed_downloads:
                arcpy.AddWarning(f"Gagal diunduh: {len(failed_downloads)}")
                for e in failed_downloads:
                    arcpy.AddWarning(f" - {e}")
            arcpy.AddMessage("Process completed successfully.")

        except Exception as e:
            arcpy.AddError(f"Tool failed: {str(e)}")
            raise


# ============================================================================================
# 5. DOWNLOAD BATAS WILAYAH (BIG REST SERVICE)
# ============================================================================================

class DownloadBatasWilayah(object):
    """Download batas wilayah administrasi dari layanan REST BIG."""

    # Provinsi data diambil dari layer KabKota (distinct wadmpr) karena
    # BATAS_WILAYAH/MapServer/12 tidak stabil / sering timeout
    URL_PROVINSI  = "https://geoservices.big.go.id/rbi/rest/services/BATASWILAYAH/Administrasi_AR_KabKota_50K/MapServer/0"
    URL_KABUPATEN = "https://geoservices.big.go.id/rbi/rest/services/BATASWILAYAH/Administrasi_AR_KabKota_50K/MapServer/0"
    URL_KECAMATAN = "https://geoservices.big.go.id/rbi/rest/services/BATASWILAYAH/Administrasi_AR_Kecamatan_10K/MapServer/0"
    URL_DESA      = "https://geoservices.big.go.id/rbi/rest/services/BATASWILAYAH/Administrasi_AR_KelDesa_10K/MapServer/0"

    PROVINSI_LIST = sorted([
        "Aceh", "Bali", "Banten", "Bengkulu", "DKI Jakarta",
        "Daerah Istimewa Yogyakarta", "Gorontalo", "Jambi",
        "Jawa Barat", "Jawa Tengah", "Jawa Timur",
        "Kalimantan Barat", "Kalimantan Selatan", "Kalimantan Tengah",
        "Kalimantan Timur", "Kalimantan Utara",
        "Kepulauan Bangka Belitung", "Kepulauan Riau", "Lampung",
        "Maluku", "Maluku Utara", "Nusa Tenggara Barat", "Nusa Tenggara Timur",
        "Papua", "Papua Barat", "Papua Barat Daya", "Papua Pegunungan",
        "Papua Selatan", "Papua Tengah", "Riau",
        "Sulawesi Barat", "Sulawesi Selatan", "Sulawesi Tengah",
        "Sulawesi Tenggara", "Sulawesi Utara",
        "Sumatera Barat", "Sumatera Selatan", "Sumatera Utara"
    ])

    def __init__(self):
        self.label = "5. Download Batas Wilayah"
        self.description = (
            "Download batas wilayah administrasi Indonesia (Provinsi, Kabupaten/Kota, "
            "Kecamatan, Kelurahan/Desa) langsung dari layanan REST Badan Informasi Geospasial (BIG). "
            "Data dapat difilter per provinsi, kabupaten/kota, dan kecamatan."
        )
        self.canRunInBackground = False

    # ------------------------------------------------------------------
    def getParameterInfo(self):
        # 0 – Tingkat / Skala Data
        p0 = arcpy.Parameter(
            displayName="Tingkat Wilayah (Skala Data)",
            name="tingkat_wilayah",
            datatype="GPString",
            parameterType="Required",
            direction="Input")
        p0.filter.type = "ValueList"
        p0.filter.list = [
            "Kabupaten/Kota (RBI 1:50K)",
            "Kecamatan (RBI 1:10K)",
            "Kelurahan/Desa (RBI 1:10K)"
        ]
        p0.value = "Kabupaten/Kota (RBI 1:50K)"

        # 1 – Filter Provinsi
        p1 = arcpy.Parameter(
            displayName="Filter Provinsi (kosongkan = semua)",
            name="filter_provinsi",
            datatype="GPString",
            parameterType="Optional",
            direction="Input")
        p1.filter.type = "ValueList"
        p1.filter.list = self.PROVINSI_LIST

        # 2 – Filter Kabupaten/Kota
        p2 = arcpy.Parameter(
            displayName="Filter Kabupaten/Kota (kosongkan = semua)",
            name="filter_kabupaten",
            datatype="GPString",
            parameterType="Optional",
            direction="Input")
        p2.filter.type = "ValueList"
        p2.filter.list = []

        # 3 – Filter Kecamatan
        p3 = arcpy.Parameter(
            displayName="Filter Kecamatan (kosongkan = semua)",
            name="filter_kecamatan",
            datatype="GPString",
            parameterType="Optional",
            direction="Input")
        p3.filter.type = "ValueList"
        p3.filter.list = []

        # 4 – Output Location
        p4 = arcpy.Parameter(
            displayName="Output Folder / Geodatabase",
            name="output_folder",
            datatype="DEWorkspace",
            parameterType="Required",
            direction="Input")

        # 5 – Output Name
        p5 = arcpy.Parameter(
            displayName="Output Name",
            name="output_name",
            datatype="GPString",
            parameterType="Required",
            direction="Input")
        p5.value = ""

        return [p0, p1, p2, p3, p4, p5]

    # ------------------------------------------------------------------
    def isLicensed(self):
        return True

    # ------------------------------------------------------------------
    def updateParameters(self, parameters):
        level_raw = parameters[0].valueAsText or "Kabupaten/Kota (RBI 1:50K)"
        # Normalize level key for logic
        if "Kabupaten"   in level_raw: level = "Kabupaten/Kota"
        elif "Kecamatan" in level_raw: level = "Kecamatan"
        else:                          level = "Kelurahan/Desa"

        prov = parameters[1].valueAsText
        kab  = parameters[2].valueAsText

        # -- Auto-fill Output GDB with project default geodatabase --
        if not parameters[4].altered:
            try:
                aprx = arcpy.mp.ArcGISProject("CURRENT")
                parameters[4].value = aprx.defaultGeodatabase
            except Exception:
                pass

        # Show/hide cascading filters based on selected level
        if level == "Kabupaten/Kota":
            parameters[1].enabled = True
            parameters[2].enabled = False
            parameters[3].enabled = False
        elif level == "Kecamatan":
            parameters[1].enabled = True
            parameters[2].enabled = True
            parameters[3].enabled = False
        else:  # Kelurahan/Desa
            parameters[1].enabled = True
            parameters[2].enabled = True
            parameters[3].enabled = True

        # Fetch Kabupaten list when:
        #   a) Provinsi value just changed (.altered), OR
        #   b) Provinsi is set but list is still empty (e.g. first open)
        if prov and (parameters[1].altered or not parameters[2].filter.list):
            try:
                kab_list = self._get_distinct(self.URL_KABUPATEN, "WADMKK",
                                              "WADMPR='{}'".format(prov))
                if kab_list != parameters[2].filter.list:
                    parameters[2].filter.list = kab_list
                    # Only clear selection if provinsi changed (not on first load)
                    if parameters[1].altered:
                        parameters[2].value = None
                        parameters[3].filter.list = []
                        parameters[3].value = None
            except Exception:
                pass

        # Fetch Kecamatan list when:
        #   a) Kabupaten value just changed (.altered), OR
        #   b) Kabupaten is set but kecamatan list is still empty
        if prov and kab and (parameters[2].altered or not parameters[3].filter.list):
            try:
                kec_list = self._get_distinct(self.URL_KECAMATAN, "WADMKC",
                                              "WADMPR='{}' AND WADMKK='{}'".format(prov, kab))
                if kec_list != parameters[3].filter.list:
                    parameters[3].filter.list = kec_list
                    if parameters[2].altered:
                        parameters[3].value = None
            except Exception:
                pass

        # Reset kab/kec lists when level changes back to simpler level
        if parameters[0].altered:
            if level in ("Provinsi", "Kabupaten/Kota"):
                parameters[2].filter.list = []
                parameters[2].value = None
                parameters[3].filter.list = []
                parameters[3].value = None
            elif level == "Kecamatan":
                parameters[3].filter.list = []
                parameters[3].value = None

        # Auto-suggest output name: WADM_<Level>_<Filter(s)>
        # Update jika masih kosong atau masih auto-generated (dimulai WADM_)
        current_name = parameters[5].valueAsText or ""
        if not current_name or current_name.startswith("WADM_"):
            level_short = {
                "Kabupaten/Kota": "KK",
                "Kecamatan":      "KC",
                "Kelurahan/Desa": "KD"
            }.get(level, level)

            parts = ["WADM", level_short]
            if prov: parts.append(re.sub(r'[^A-Za-z0-9]', '_', prov))
            kec = parameters[3].valueAsText
            if kab:  parts.append(re.sub(r'[^A-Za-z0-9]', '_', kab))
            if kec:  parts.append(re.sub(r'[^A-Za-z0-9]', '_', kec))
            parameters[5].value = "_".join(parts)

        return

    # ------------------------------------------------------------------
    def updateMessages(self, parameters):
        level_raw = parameters[0].valueAsText
        if "Kabupaten" in (level_raw or ""): level = "Kabupaten/Kota"
        elif "Kecamatan" in (level_raw or ""): level = "Kecamatan"
        else: level = "Kelurahan/Desa"
        prov  = parameters[1].valueAsText
        kab   = parameters[2].valueAsText

        # Warn (not error) when downloading large datasets without filter
        if level == "Kelurahan/Desa" and not prov:
            parameters[1].setWarningMessage(
                "Tanpa filter provinsi, semua data desa/kelurahan Indonesia (~80.000+ fitur) akan diunduh. "
                "Ini dapat memakan waktu sangat lama. Disarankan pilih provinsi terlebih dahulu."
            )
        elif level == "Kelurahan/Desa" and prov and not kab:
            parameters[2].setWarningMessage(
                "Tanpa filter kabupaten, semua desa/kelurahan di provinsi ini akan diunduh. "
                "Proses mungkin membutuhkan waktu cukup lama."
            )
        elif level == "Kecamatan" and not prov:
            parameters[1].setWarningMessage(
                "Tanpa filter provinsi, semua kecamatan Indonesia (~7.000+ fitur) akan diunduh."
            )
        return


    # ------------------------------------------------------------------
    # Helper: get distinct field values (for dropdown population)
    def _get_distinct(self, base_url, field, where="1=1"):
        try:
            import requests as _req
            params = {
                "where": where,
                "outFields": field,
                "returnGeometry": "false",
                "returnDistinctValues": "true",
                "orderByFields": field,
                "f": "json"
            }
            url = "{}/query".format(base_url)
            resp = _req.get(url, params=params, verify=False,
                            timeout=(10, 30))
            resp.raise_for_status()
            data = resp.json()
            return sorted(set(
                (f["attributes"].get(field) or "").strip()
                for f in data.get("features", [])
                if f["attributes"].get(field)
            ))
        except Exception:
            return []

    # Helper: download all features with pagination + retry
    def _query_all(self, base_url, where="1=1"):
        import requests as _req

        all_features = []
        offset = 0
        batch  = 1000
        max_retries = 3

        while True:
            params = {
                "where": where,
                "outFields": "*",
                "f": "geojson",
                "resultOffset": offset,
                "resultRecordCount": batch,
                "orderByFields": "objectid"
            }
            url = "{}/query".format(base_url)

            # Retry loop per batch
            for attempt in range(1, max_retries + 1):
                try:
                    resp = _req.get(url, params=params, verify=False,
                                    timeout=(15, 120))  # (connect 15s, read 120s)
                    resp.raise_for_status()
                    data = resp.json()
                    break  # success
                except Exception as e:
                    if attempt == max_retries:
                        raise Exception(
                            "Gagal mengunduh batch offset={} setelah {} percobaan: {}".format(
                                offset, max_retries, str(e))
                        )
                    arcpy.AddWarning("  Percobaan {}/{} gagal, mencoba ulang...".format(
                        attempt, max_retries))
                    time.sleep(5 * attempt)

            batch_features = data.get("features", [])
            all_features.extend(batch_features)
            arcpy.AddMessage("  Fetched {} features...".format(len(all_features)))

            if len(batch_features) < batch:
                break
            offset += batch


        return {"type": "FeatureCollection", "features": all_features}

    # ------------------------------------------------------------------
    def execute(self, parameters, messages):
        # License check
        valid, msg, info = SupabaseGuard.check_license(
            app_name="BIG Downloader ArcPro", minimum_tier="free", show_machine_id=False)
        messages.addMessage(msg)
        if not valid:
            raise Exception("Lisensi tidak valid. Hubungi admin.")

        level_raw  = parameters[0].valueAsText
        if "Provinsi"    in (level_raw or ""): level = "Provinsi"
        elif "Kabupaten" in (level_raw or ""): level = "Kabupaten/Kota"
        elif "Kecamatan" in (level_raw or ""): level = "Kecamatan"
        else:                                  level = "Kelurahan/Desa"

        prov       = parameters[1].valueAsText
        kab        = parameters[2].valueAsText
        kec        = parameters[3].valueAsText
        out_folder = parameters[4].valueAsText
        out_name   = parameters[5].valueAsText

        # Sanitize output name
        safe_name = re.sub(r'[^A-Za-z0-9_]', '_', out_name)

        # Resolve URL and WHERE clause
        if level == "Kabupaten/Kota":
            svc_url = self.URL_KABUPATEN
            parts   = ["1=1"]
            if prov: parts.append("WADMPR='{}'".format(prov))
            where   = " AND ".join(parts)
        elif level == "Kecamatan":
            svc_url = self.URL_KECAMATAN
            parts   = ["1=1"]
            if prov: parts.append("WADMPR='{}'".format(prov))
            if kab:  parts.append("WADMKK='{}'".format(kab))
            where   = " AND ".join(parts)
        else:  # Kelurahan/Desa
            svc_url = self.URL_DESA
            parts   = ["1=1"]
            if prov: parts.append("WADMPR='{}'".format(prov))
            if kab:  parts.append("WADMKK='{}'".format(kab))
            if kec:  parts.append("WADMKC='{}'".format(kec))
            where   = " AND ".join(parts)

        arcpy.AddMessage("\n=== DOWNLOAD BATAS WILAYAH (BIG) ===")
        arcpy.AddMessage("Tingkat   : {}".format(level))
        arcpy.AddMessage("Provinsi  : {}".format(prov or "Semua"))
        arcpy.AddMessage("Kabupaten : {}".format(kab or "-"))
        arcpy.AddMessage("Kecamatan : {}".format(kec or "-"))
        arcpy.AddMessage("Mengunduh data dari server BIG...")

        geojson_data = self._query_all(svc_url, where)
        total = len(geojson_data["features"])

        if total == 0:
            raise Exception("Tidak ada data ditemukan dengan filter yang dipilih.")

        arcpy.AddMessage("Total fitur: {}".format(total))

        # Write GeoJSON to temp file
        import tempfile as _tmp
        tmp_dir  = arcpy.env.scratchFolder or _tmp.gettempdir()
        tmp_json = os.path.join(tmp_dir, "{}_temp.geojson".format(safe_name))

        with open(tmp_json, "w", encoding="utf-8") as f:
            json.dump(geojson_data, f, ensure_ascii=False)

        arcpy.AddMessage("Konversi ke Feature Class...")

        out_path = os.path.join(out_folder, safe_name)
        arcpy.conversion.JSONToFeatures(tmp_json, out_path)

        try:
            os.remove(tmp_json)
        except Exception:
            pass

        arcpy.AddMessage("Berhasil! Data tersimpan di: {}".format(out_path))

        # Add to active map
        try:
            aprx = arcpy.mp.ArcGISProject("CURRENT")
            mp   = aprx.activeMap
            if mp:
                mp.addDataFromPath(out_path)
                arcpy.AddMessage("Layer berhasil ditambahkan ke peta.")
        except Exception:
            pass

        arcpy.AddMessage("=== SELESAI ===")
