# -*- coding: utf-8 -*-
"""
BIG Downloader Toolbox
Plugin untuk mengunduh data BIG (DEMNAS, RBI, BATNAS)
"""


def classFactory(iface):
    """Load BIG Downloader Toolbox plugin"""
    from .big_downloader_toolbox_plugin import BIGDownloaderToolboxPlugin
    return BIGDownloaderToolboxPlugin(iface)