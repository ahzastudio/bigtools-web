# -*- coding: utf-8 -*-
import sys
import os
import importlib.machinery

major, minor = sys.version_info[:2]
current_dir = os.path.dirname(__file__)
pyc_folder = os.path.join(current_dir, "bin", f"py{major}{minor}")

module_filename = os.path.basename(__file__)
module_name_only = os.path.splitext(module_filename)[0]
pyc_path = os.path.join(pyc_folder, f"{module_name_only}.pyc")

if os.path.exists(pyc_path):
    module_name = __name__
    loader = importlib.machinery.SourcelessFileLoader(module_name, pyc_path)
    sys.path.insert(0, pyc_folder)
    try:
        code = loader.get_code(module_name)
        exec(code, globals())
    finally:
        if pyc_folder in sys.path:
            sys.path.remove(pyc_folder)
else:
    raise ImportError(f"QGIS Python version {major}.{minor} is not supported by this compiled plugin.")
