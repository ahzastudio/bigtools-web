# Changelog — BIG Downloader Toolbox (QGIS Plugin)

---

## [4.0.4] — 2026-08-09

### 🔧 Fixed
- **Kompatibilitas QGIS 4.x / PyQt6 penuh** — semua penggunaan Enum yang menggunakan sintaks lama QGIS 3.x telah diperbarui ke namespace lengkap yang disyaratkan PyQt6:
  - `Qgis.Critical` → `Qgis.MessageLevel.Critical`
  - `QgsProcessing.TypeVectorPolygon` → `QgsProcessing.SourceType.TypeVectorPolygon`
  - `QgsProcessingParameterField.String` → `QgsProcessingParameterField.DataType.String`
  - `QgsVectorFileWriter.NoError` → `QgsVectorFileWriter.WriterError.NoError`
  - `QgsProcessingParameterNumber.Double` → `QgsProcessingParameterNumber.Type.Double`
  - `QgsProcessingParameterFile.File` → `QgsProcessingParameterFile.Behavior.File`
- File terdampak: `big_downloader_toolbox_plugin.py`, `big_downloader_toolbox_provider.py`, `algorithms/download_batnas.py`, `algorithms/download_demnas_pro.py`, `algorithms/download_rbi_tool_pro.py`, `algorithms/download_peta_cetak_rbi.py`, `algorithms/import_big_metadata.py`

---

## [4.0.3] — 2026-08

### ✨ New Features
- Penambahan tool **Download Peta Cetak RBI** (download file PDF/gambar peta cetak RBI berbasis AOI)
- Peningkatan sistem obfuskasi kode untuk distribusi via website

### 🔧 Fixed
- Perbaikan stabilitas koneksi download pada jaringan lambat
- Perbaikan penanganan error saat AOI tidak memiliki fitur valid

---

## [4.0.2] — 2026-07

### ✨ New Features
- Penambahan tool **Download BATNAS** (Batimetri Nasional) — download data kedalaman laut nasional berbasis grid index
- Penambahan tool **Import Metadata BIG** — import dan parsing metadata ISO 19115-3 dari file XML BIG/INA-Geoportal

### 🔧 Fixed
- Perbaikan kompatibilitas format GeoPackage output
- Perbaikan validasi CRS pada proses mosaic DEMNAS

---

## [4.0.1] — 2026-06

### 🚀 Initial Release (QGIS Plugin)
- Tool **Login INA-Geoportal** — panduan dan helper untuk mendapatkan token API
- Tool **Download DEMNAS Pro** — download Digital Elevation Model Nasional dengan auto-mosaic, buffer AOI, dan ekspor ke GeoTIFF
- Tool **Download RBI 1:50K** — download tile Rupabumi Indonesia skala 1:50.000
- Tool **Download RBI 1:25K** — download tile Rupabumi Indonesia skala 1:25.000
- Tool **Download RBI 1:10K** — download tile Rupabumi Indonesia skala 1:10.000
- Dukungan QGIS 3.22+ hingga 4.x
- Sistem lisensi berbasis Supabase untuk versi Pro
