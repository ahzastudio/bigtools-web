# BIG Downloader Toolbox - QGIS Plugin

Plugin untuk mengunduh data BIG (Badan Informasi Geospasial) Indonesia:
- **DEMNAS** - Digital Elevation Model Nasional
- **RBI** - Rupabumi Indonesia  
- **BATNAS** - Batimetri Nasional

## 🚀 Quick Start

1. **Dapatkan Token API:**
   - Jalankan Tool #1: Login INA-Geoportal
   - Browser akan terbuka
   - Login dan ambil accessToken dari Developer Tools (F12 → Network → signin)

2. **Download Data:**
   - Gunakan Tool #2, #3, atau #4 sesuai kebutuhan
   - Paste token API yang sudah didapat
   - Pilih parameter yang diperlukan
   - Klik Run

## 📍 Lokasi Tools

- **Menu:** Plugins → BIG Downloader Toolbox
- **Toolbar:** BIG Downloader Toolbox
- **Processing Toolbox:** BIG Downloader Tools

## 🔧 Tools Available

1. **Login INA-Geoportal** - Panduan mendapatkan token API
2. **Download DEMNAS (Mosaic)** - Download DEM dengan mosaic otomatis
3. **Download RBI** - Download peta Rupabumi Indonesia
4. **Download BATNAS** - Download data batimetri nasional

## 📖 Documentation

Lihat file berikut untuk dokumentasi lengkap:
- `installation_guide.md` - Panduan instalasi dan troubleshooting
- `walkthrough.md` - Dokumentasi lengkap fitur
- `icon_documentation.md` - Dokumentasi icon

## ⚠️ Requirements

- QGIS 3.x
- Python 3.9+
- Koneksi internet
- Token API dari INA-Geoportal

## 📞 Support

Jika mengalami masalah, cek Python Console di QGIS untuk error messages.

**Data Source:** https://tanahair.indonesia.go.id
